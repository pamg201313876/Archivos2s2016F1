#ifndef ANALIZADOR_INCLUDED
#define ANALIZADOR_INCLUDED

#include </home/paublo/Proyecto/Archivos/Discos.h>

struct Cadena
{

    char caracteres[150];


};


typedef struct Cadena Token;

char comando[200];                  ///lo que vas ingresnado
char comandoCompleto[200];          ///despues de concatenar multilinea este guarda todo el cumando
Token Tokens[500];                  /// vector de tokens para analisis sintactico
int contadorTokens = 0;             ///cuenta cuantos tokens llevamos almacenados
char fx[2];
char fullArchivo[10000];
int zz=0;
int hallado=0; ///0 no, 1 si

/**VARIABLES EN EL MANEJO DE ARCHIVOS*/

/** variables para mkfile*/
char mkfileId[30];
char mkfilePath[150];
int mkfileSize = 0;
char mkfileCont[150];
int mkfileP=0;

/** variables para cat*/
char catId[30];
char catPath[150];

/** variables para rem*/
char remId[30];
char remPath[150];

/** variables para edit*/
char editId[30];
char editPath[150];
int editSize;
char editCont[150];

/** variables para ren*/
char renId[30];
char renPath[150];
char renName[30];

/** variables para mkdir*/

char mkdirId[30];
char mkdirPath[150];
char mkdirP = 0;

particionMontada f;
/** variables para cp*/

char cpId[30];
char cpPath[150];

/** variables para mv*/
char mvId[30];
char mvPath[150];
char mvDest[150];
char mvIddest[30];

/** variables para find*/
char findId[30];
char findPath[150];
char findName[50];

/** variables para recovery*/
char recoveryId[30];

/** variables para loss*/
char lossId[30];

/** variables para rep*/
char repName[10];
char repPath[150];
char repId[30];
char repRuta[150];

char execPath[150];


/**VARIABLES EN EL MANEJO DE DISCOS */

/** variables para mkdisk */
int mkdiskSize = 0;
char mkdiskUnit[2];
char mkdiskPath[150];
char mkdiskName[150];

/** variables para RmDisk*/

int fdiskSize = 0;
char fdiskUnit[2];
char fdiskPath[150];
char fdiskType[2];
char fdiskFit[2];
char fdiskDelete[5];
char fdiskName[30];
int fdiskAdd = 0;

char rmdiskPath[150];

/** variables para mount*/
char mountPath[150];
char mountName[3];

/** variables para unmount*/
char unmountid[30];

/** variables para mkfs*/
char mkfsId[30];
char mkfsType[5];



char contenidoArchivo[10000];
int opc = 0;
int del = 0;
int add = 0;
int reps = 0;


int y;


int analisisLexico(char comandoFull[])
{

    int u = 0;
    int xx = 0;
    char TokenGuardado[150];
    int comilla = 0;

    if(strlen(comandoFull) > 4)
    {


        for(u = 0; u < strlen(comandoFull); u++)
        {

           // printf("%c \n", comandoFull[u] );


            if( 65 <= comandoFull[u] && comandoFull[u] <= 90  )
            {

                if(!strcmp(TokenGuardado,":"))
                {

                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado

                }

                char g[2];                                                      ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u]+32;                                       ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                                    ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                                        ///asi puedo concatenarlo
                xx = 1;

            }
            else if(48 <= comandoFull[u] && comandoFull[u] <= 57 )
            {



                if(!strcmp(TokenGuardado,":"))
                {

                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado
                }


                char g[2];                                                      ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u];                                          ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                                    ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                                        ///asi puedo concatenarlo
                xx = 1;




            }
            else if(97 <= comandoFull[u] && comandoFull[u] <= 122 || comandoFull[u] == '_' )
            {

                if(!strcmp(TokenGuardado,":"))
                {

                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado

                }

                char g[2];                                                      ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u];                                          ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                                    ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                                        ///asi puedo concatenarlo
                xx = 1;

            }
            else if(92 == comandoFull[u]   || comandoFull[u] == '\t'    || comandoFull[u] == '\n')
            {
                if( strlen(TokenGuardado)!=0)
                {

                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado
                }
         xx = 1;

            }
            else if ( comandoFull[u] == ' ')
            {

                if( strlen(TokenGuardado)!=0)
                {
                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado
                }
                xx=1;


            }
            else if ( comandoFull[u] == 34)
            {


                if(!strcmp(TokenGuardado,":"))
                {

                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);    ///concateno en un token u el tokenguardado
                    contadorTokens++;                                           ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                   ///vacio el char TokenGuardado

                }

                strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado

                u++;                                                        ///me salto la actual que es la comilla

                while(comandoFull[u] != 34)
                {

                    if( 65 <= comandoFull[u] && comandoFull[u] <= 90  )
                    {

                        char g[2];                                                      ///declaro un char G de 2 posiciones
                        g[0] = comandoFull[u]+32;                                       ///en la posicion 0 meto el char que leo
                        g[1] = '\0';                                                    ///en la posicion 1 meto el fin de cadena
                        strcat(TokenGuardado,g);                                        ///asi puedo concatenarlo
                        u++;
                    }
                    else
                    {

                        char g[2];                                                  ///declaro un char G de 2 posiciones
                        g[0] = comandoFull[u];                                      ///en la posicion 0 meto el char que leo
                        g[1] = '\0';                                                ///en la posicion 1 meto el fin de cadena
                        strcat(TokenGuardado,g);                                    ///asi puedo concatenarlo
                        u++;
                    }
                }



                xx=1;


            }
            else if(comandoFull[u] == '+'  || comandoFull[u] == '-' || comandoFull[u] == '/'  || comandoFull[u] == '.' )
            {

                if( !strcmp(TokenGuardado,":"))
                {
                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado
                }

                char g[2];                                          ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u];                              ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                        ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                            ///asi puedo concatenarlo
                xx = 1;


            }
            else if(comandoFull[u] == ':' )
            {


                if( strlen(TokenGuardado)!=0)
                {



                    strcat(Tokens[contadorTokens].caracteres,TokenGuardado);        ///concateno en un token u el tokenguardado
                    contadorTokens++;                                               ///sumo los tokens que llevo
                    strcpy(TokenGuardado,"");                                       ///vacio el char TokenGuardado



                }
                char g[2];                                                      ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u];                                          ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                                    ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                                        ///asi puedo concatenarlo
                xx = 1;





            }
            else if(comandoFull[u] == '#')
            {

                char g[2];                                          ///declaro un char G de 2 posiciones
                g[0] = comandoFull[u];                              ///en la posicion 0 meto el char que leo
                g[1] = '\0';                                        ///en la posicion 1 meto el fin de cadena
                strcat(TokenGuardado,g);                            ///asi puedo concatenarlo
                xx = 1;

                while(comandoFull[u] != '\n')
                {

                    char g[2];                                                  ///declaro un char G de 2 posiciones
                    g[0] = comandoFull[u];                                      ///en la posicion 0 meto el char que leo
                    g[1] = '\0';                                                ///en la posicion 1 meto el fin de cadena
                    strcat(TokenGuardado,g);                                    ///asi puedo concatenarlo
                    u++;
                }


            }
            else
            {

                printf("Error: Tokens almacenados: %d,%d,%c\n",contadorTokens,u,comandoFull[u]);
                return 0;
            }


        }
    }



    return xx;


}


int verificarMultilinea()
{


    if(comando[strlen(comando)-1] == '\\') //comando multilinea
    {


        return 1;

    }
    else
    {

        return 0;

    }


}


void ingresar()
{


    printf("Ingrese Su Comando: \n");
    fgets(comando, 200, stdin);
    fflush(stdin);

    if(verificarMultilinea())
    {
        strcat(comandoCompleto,comando);///completo el comando poco a poco con los espacios y todo lo demas
        ingresar();///lo hacemos hasta que ya no vengan mas
    }
    else
    {
        strcat(comandoCompleto,comando);

    }


}


void ingresar2(char *f)
{

    if(verificarMultilinea())
    {
        strcat(comandoCompleto,f);///completo el comando poco a poco con los espacios y todo lo demas
        ingresar();///lo hacemos hasta que ya no vengan mas
    }
    else
    {
        printf("nio");
        strcat(comandoCompleto,f);

    }


}


void imprimirTokens(Token Tok[])
{
    int w = 0;
    printf("Impresion Tokens: \n");
    for(w = 0; w < contadorTokens; w++)
    {

        printf("%s \n",Tok[w].caracteres);

    }

}


void limpiezaTokens()
{

    int w = 0;

    strcpy(comando,"");
    strcpy(comandoCompleto,"");


    Token Tokens2[500];

    for(w = 0; w < contadorTokens; w++)
    {

        strcpy(Tokens[w].caracteres,"");
        ///  printf("limpie el token en teoria %s ,\n",Tokens[w].caracteres);

    }

    contadorTokens = 0;




}



int analisisSintactico(Token Tok[])
{


    int x=0;
    int state = 0;
    strcpy(mkdiskUnit,"");
    strcpy(mkfileCont,"");
    strcpy(contenidoArchivo,"");


    for( x = 0; x < contadorTokens; x++)
    {

        char tokActual[150];                                ///aca se guardara el string del token leido
        strcpy(tokActual,Tok[x].caracteres);                ///copiamos el contenido

     /// printf("%s %d\n",Tok[x].caracteres,state);

        switch(state)
        {


        case 0:
            if(strstr(tokActual,"mkdisk"))
            {
                state = 1;


            }
            else  if(strstr(tokActual,"rmdisk"))
            {

                state = 2;


            }
            else  if(strstr(tokActual,"fdisk"))
            {

                state = 3;
                // printf("Es fdisk\n");


            }
            else  if(strstr(tokActual,"mount"))
            {

                state = 4;
                // printf("es mount\n");

                if(strstr(tokActual,"unmount"))
                {

                    state = 5;
                    // printf("es unmount\n");

                }

            }
            else  if(strstr(tokActual,"df"))
            {

                state = 21;


            }
            else  if(strstr(tokActual,"du"))
            {

                state = 22;


            }
            else  if(strstr(tokActual,"mkfs"))
            {

                state = 6;


            }
            else  if(strstr(tokActual,"mkfile"))
            {

                state = 7;
                ///  printf("Es mkfile \n");


            }
            else  if(strstr(tokActual,"cat"))
            {

                state = 8;


            }
            else  if(strstr(tokActual,"rem"))
            {

                state = 9;


            }
            else  if(!strcmp(tokActual,"edit"))
            {

                state = 10;


            }
            else  if(!strcmp(tokActual,"edit"))
            {

                state = 11;


            }
            else  if(!strcmp(tokActual,"ren"))
            {

                state = 12;


            }
            else  if(strstr(tokActual,"mkdir"))
            {

                state = 13;


            }
            else  if(!strcmp(tokActual,"cp"))
            {

                state = 14;


            }
            else  if(!strcmp(tokActual,"mv"))
            {

                state = 15;


            }
            else  if(!strcmp(tokActual,"find"))
            {

                state = 16;


            }
            else  if(!strcmp(tokActual,"recovery"))
            {

                state = 17;


            }
            else  if(!strcmp(tokActual,"loss"))
            {

                state = 18;


            }
            else  if(strstr(tokActual,"rep"))
            {

                state = 19;


            }
            else  if(strstr(tokActual,"exec"))
            {

                state = 20;

            }
            else  if(!strcmp(tokActual,"#"))
            {

                state = 250;


            }

            else
            {
                printf("Comando no reconocido       %s,%d,%c,%c\n",tokActual,strlen(tokActual),tokActual[0],tokActual[strlen(tokActual)-1]);
                printf("Comando no reconocido\n");
                state=1000;

            }
            break;


/*****************COMANDO NO. 1 *************************************************************************************/

        case 1:                                         ///comando mkdisk



            if(!strcmp(tokActual,"-size"))
            {
                state = 21;
                opc = 1;
            }
            else if(!strcmp(tokActual,"+unit"))
            {
                state = 21;
                opc = 2;
            }
            else if(!strcmp(tokActual,"-path"))
            {
                state = 21;
                opc = 3;
            }
            else if(!strcmp(tokActual,"-name"))
            {
                state = 21;
                opc = 4;
            }
            else
            {
                printf("Opcion no reconocida  %s \n",tokActual);
                state=1000;
            }
            break;



        case 21:

            if(!strcmp(tokActual,":"))
            {

                state = 22;

            }else{

                printf("Se esperaba :\n");
                state = 1000;

            }
            break;



        case 22:


            if(!strcmp(tokActual,":"))
            {

                switch(opc){

                case 1:
                state = 23;
                break;

                case 2:
                state = 24;
                break;


                case 3:
                state = 25;
                break;


                case 4:
                state = 26;
                break;


                default:
                break;

                }

            }else{

                printf("Se esperaba : \n");
                state = 1000;

            }
            break;


        case 23:

            y = atoi(tokActual);
            if(y > 0)
            {

                mkdiskSize = y;

                if(!strcmp(mkdiskName,"")  || !strcmp(mkdiskPath,"") || x != contadorTokens -1){
                    state=1;
                }

                if(strcmp(mkdiskName,"")  && strcmp(mkdiskPath,"")  && mkdiskSize != 0  && x == contadorTokens-1 ){
                    state = 101;
                    x--;
                }else if(x == contadorTokens-1){

                    printf("Falta uno o mas parametros obligatorios \n");
                }


            }
            else
            {
                printf("El tamanio debe ser mayor a 0 %s \n",tokActual);
                state=1000;
            }

            break;



        case 24:

            if(!strcmp(tokActual,"k") || !strcmp(tokActual,"m") || !strcmp(tokActual,"b"))
            {
                strcpy(mkdiskUnit,tokActual);
                if(!strcmp(mkdiskName,"")  || !strcmp(mkdiskPath,"")  || mkdiskSize == 0 || x != contadorTokens -1 ){
                    state=1;
                }


                if(strcmp(mkdiskName,"")  && strcmp(mkdiskPath,"")  && mkdiskSize != 0  && x == contadorTokens-1 ){
                    state = 101;
                    x--;
                }else if(x == contadorTokens-1){

                    printf("Falta uno o mas parametros obligatorios \n");
                }

            }
            else if(strlen(tokActual)>0)
            {
                printf("Unidad no reconocida\n");
                state=1000;
            }

            break;


        case 25:
            if(strlen(tokActual)>0)
            {
                strcpy(mkdiskPath,tokActual);
                if(!strcmp(mkdiskName,"")   || mkdiskSize == 0  || x != contadorTokens -1){
                    state=1;
                }

                if(strcmp(mkdiskName,"")  && strcmp(mkdiskPath,"")  && mkdiskSize != 0  && x == contadorTokens-1 ){
                    state = 101;
                    x--;
                }else if(x == contadorTokens-1){

                    printf("Falta uno o mas parametros obligatorios \n");
                }


            }
            else
            {
                printf("Ingrese una ruta valida\n");
                state=1000;
            }
            break;


        case 26:

            if(strlen(tokActual)>0)
            {
                strcpy(mkdiskName,tokActual);

                if( !strcmp(mkdiskPath,"")  || mkdiskSize == 0  || x != contadorTokens -1){
                    state=1;
                }

                if(strcmp(mkdiskName,"")  && strcmp(mkdiskPath,"")  && mkdiskSize != 0  && x == contadorTokens-1 ){
                    state = 101;
                    x--;
                }else if(x == contadorTokens-1){

                    printf("Falta uno o mas parametros obligatorios \n");
                }

            }
            else
            {

                printf("Ingrese un Nombre valida\n");
                state=1000;

            }
            break;



        case 101:

            if(!strcmp(mkdiskUnit,""))
            {
                strcpy(mkdiskUnit,"m");         ///si de casualidad no venia unidad se toma como M
            }

           /** printf("Los valores para creacion de discos son:\n");
            printf("Tamanio:    %d\n",mkdiskSize);
            printf("Unidad:     %s\n",mkdiskUnit);
            printf("Ruta:       %s\n",mkdiskPath);
            printf("Nombre:     %s\n",mkdiskName);**/
            printf("\n*******************Creacion de Disco********************\n");
            char completo[500];
            strcpy(completo,"");
            strcat(completo,mkdiskPath);
            strcat(completo,mkdiskName);
            crearDisco(mkdiskSize,mkdiskPath,mkdiskName,mkdiskUnit);

            mkdiskSize=0;
            strcpy(mkdiskUnit,"");
            strcpy(mkdiskPath,"");
            strcpy(mkdiskName,"");
            opc = 0;

            break;

/************************COMANDO NO 2**************************************************************************/


        case 2:
            if(!strcmp(tokActual,"-path"))             ///comando rmdisk
            {
                state = 37;
            }
            else
            {
               printf("Opcion no reconocida %s",tokActual);
               state=1000;
            }

            break;


        case 37:
            if(!strcmp(tokActual,":"))             ///comando rmdisk
            {
                state = 38;
            }
            else
            {
                printf("Se esperaba : \n");
                state=1000;
            }

            break;

        case 38:
            if(!strcmp(tokActual,":"))             ///comando rmdisk
            {
                state = 39;
            }
            else
            {
                printf("Se esperaba : \n");
                state=1000;
            }

            break;


        case 39:


            if(strlen(tokActual)>0)             ///comando rmdisk
            {
                state = 102;
                strcpy(rmdiskPath,tokActual);
                x--;
            }
            else
            {
                printf("Ingrese una ruta valida\n");
                state=1000;
            }

            break;


        case 102:

           /** printf("\n\nLos datos para eliminar un disco son: \n");
            printf("La ruta:    %s\n",rmdiskPath);**/

            printf("\n****************** Eliminacion de Disco ********************\n");
            printf("\nDesea eliminar el disco %s??? Y/N\n",rmdiskPath);
            char respuesta[3];
            fgets(&respuesta,3,stdin);

            printf("Usted ingreso: %s\n",respuesta);
            if(strstr(respuesta,"y"))
            {
              borrarDisco(rmdiskPath);
            }
            else if(strstr(respuesta,"n"))
            {
                printf("No se elimino el disco...\n");
            }
            strcpy(respuesta,"");
            strcpy(rmdiskPath,"");

            break;



/********************COMANDO NO. 3 ****************************************************************************/

     case 3:

            if(!strcmp(tokActual,"-size"))
            {
                state = 27;
                opc = 1;
            }
            else if(!strcmp(tokActual,"+unit"))
            {
                state = 27;
                opc = 2;
            }
            else if(!strcmp(tokActual,"-path"))
            {
                state = 27;
                opc = 3;
            }
            else  if(!strcmp(tokActual,"+type"))
            {
                state = 27;
                opc = 4;
            }
            else if(!strcmp(tokActual,"+fit"))
            {
               state = 27;
                opc = 5;
            }
            else  if(!strcmp(tokActual,"+delete"))
            {
                state = 27;
                opc = 6;

            }
            else  if(!strcmp(tokActual,"-name"))
            {
                state = 27;
                opc = 7;

            }
            else  if(!strcmp(tokActual,"+add"))
            {
                state = 27;
                opc = 8;
            }
            else
            {
                state=1000;
                printf("Parametro no reconocido para fdisk %s %d\n",tokActual,x);
            }

            break;


        case 27:

            if(!strcmp(tokActual,":"))
            {
                state = 28;
            }
            else
            {
                printf("Se esperaba :\n");
                state = 1000;

            }
            break;



        case 28:


            if(!strcmp(tokActual,":"))
            {
              ///  printf("%d\n",opc);

                switch(opc){

                case 1:

                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 29;
                    }else{
                        state = 29;
                    }

                break;

                case 2:

                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 30;
                    }else{
                        state = 30;
                    }

                break;


                case 3:
                    if(del == 1){
                        state = 31;
                    }else if(add == 1){
                        state = 31;
                    }else{
                        state = 31;
                    }

                break;


                case 4:
                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 1000;
                    }else{
                        state = 32;
                    }
                break;


                case 5:
                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 1000;
                    }else{
                        state = 33;
                    }
                break;

                case 6:
                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 1000;
                    }else{
                        state = 34;
                    }
                break;

                case 7:
                    if(del == 1){
                        state = 35;
                    }else if(add == 1){
                        state = 35;
                    }else{
                        state = 35;
                    }
                break;

                case 8:
                    if(del == 1){
                        state = 1000;
                    }else if(add == 1){
                        state = 1000;
                    }else{
                        state = 36;
                    }

                break;

                default:
                break;

                }

            }
            else
            {
                printf("Se esperaba : \n");
                state = 1000;
            }
            break;



        case 29:


            if(atoi(tokActual) > 0)
            {

                fdiskSize = atoi(tokActual);

                if(!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")   ){
                    state=3;
                }


                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }


            }
            else
            {
                printf("El tamanio debe ser mayor a 0\n");
                state=1000;
            }
            break;


        case 30:


            if(!strcmp(tokActual,"k") || !strcmp(tokActual,"m") || !strcasecmp(tokActual,"b"))
            {
                strcpy(fdiskUnit,tokActual);


                if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")  || fdiskSize == 0)  && del == 0 && add == 0 ){
                    state=3;
                }else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 1 && add == 0)
                {
                    state = 3;
                }
                else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 0 && add == 1)
                {
                    state = 3;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 && del == 0 && add ==0){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }else if( (del != 0  && (strcmp(fdiskName,"")  && strcmp(fdiskPath,"") )   && x == contadorTokens-1 )  ||  (add != 0  && ( strcmp(fdiskName,"")  && strcmp(fdiskPath,"") )  && x == contadorTokens-1 ) )
                {

                    state = 103;
                    x--;
                }else{

                    state = 3;
                }

            }
            else
            {

                printf("Unidad no reconocida %s\n",tokActual);
                state=1000;

            }
            break;


        case 31:

            if(strlen(tokActual)>0)
            {

                strcpy(fdiskPath,tokActual);
                if((!strcmp(fdiskName,"")  || fdiskSize == 0 )  && del == 0 && add == 0 ){
                    state=3;
                }else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 1 && add == 0)
                {
                    state = 3;
                }
                else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 0 && add == 1)
                {
                    state = 3;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 && del == 0 && add ==0){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }else if( (del != 0  && (strcmp(fdiskName,"")  && strcmp(fdiskPath,"") )  && x == contadorTokens-1 )  ||  (add != 0  && ( strcmp(fdiskName,"")  && strcmp(fdiskPath,"") )  && x == contadorTokens-1) ){

                    state = 103;
                    x--;
                }else{

                    state = 3;
                }



            }
            else
            {

                printf("Ingrese una ruta valida\n");
                state=1000;

            }
            break;




        case 32:

            if(!strcmp(tokActual,"p") || !strcmp(tokActual,"l")  || !strcmp(tokActual,"e")  )
            {
                strcpy(fdiskType,tokActual);

                if(!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")  || fdiskSize == 0  ){
                    state=3;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }
            }
            else
            {

                state = 1000;
                printf("Tipo no reconocido \n");

            }

            break;


        case 33:

            if(!strcmp(tokActual,"bf") || !strcmp(tokActual,"ff")  || !strcmp(tokActual,"wf")  )
            {
                strcpy(fdiskFit,tokActual);

                if(!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")  || fdiskSize == 0  ){
                    state=3;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }

            }
            else
            {

                state = 1000;
                printf("Ajuste no reconocido \n");

            }

            break;



        case 34:


            if(!strcmp(tokActual,"fast") || !strcmp(tokActual,"full"))
            {

                strcpy(fdiskDelete,tokActual);

                if(!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")  || fdiskSize == 0  ){
                    state=3;
                    del = 1;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;

                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }


            }
            else
            {

                state = 1000;
                printf("Valor no reconocido \n");

            }

            break;

        case 35:

            // printf("El name que ingresare \n");
            if(strlen(tokActual)>0)
            {
                strcpy(fdiskName,tokActual);

                if((!strcmp(fdiskPath,"")  || fdiskSize == 0 )  && del == 0 && add == 0 ){
                    state=3;
                }else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 1 && add == 0)
                {
                    state = 3;
                }
                else if((!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"") ) && del == 0 && add == 1)
                {
                    state = 3;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 && del == 0 && add ==0){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }else if( (del != 0  && (strcmp(fdiskName,"")  && strcmp(fdiskPath,"") ) && x == contadorTokens-1 )  ||  (add != 0  && ( strcmp(fdiskName,"")  && strcmp(fdiskPath,"") ) && x == contadorTokens-1 ) ){

                    state = 103;
                    x--;

                }else{

                    state = 3;
                }

            }
            else
            {

                state = 1000;
                printf("Ingrese un nombre valido \n");

            }

            break;




        case 36:

            //printf("detecto el add\n");
            if(atoi(tokActual)!=0)
            {


                fdiskAdd = atoi(tokActual);
                if(!strcmp(fdiskName,"")  || !strcmp(fdiskPath,"")  || fdiskSize == 0  ){
                    state=3;
                    add = 1;
                }

                if(strcmp(fdiskName,"")  && strcmp(fdiskPath,"")  && fdiskSize != 0  && x == contadorTokens-1 ){
                    state = 103;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios \n");
                    state = 1000;
                }


            }
            else
            {

                state = 1000;
                printf("El tamanio a agregar o quitar debe ser distinto a 0 \n");

            }

            break;


  case 103:

            // printf("entre al 103");

            if(!strcmp(fdiskUnit,""))
            {
                strcpy(fdiskUnit,"k");         ///si de casualidad no venia unidad se toma como M
            }

            if(!strcmp(fdiskType,""))
            {
                strcpy(fdiskType,"p");         ///si de casualidad no venia tipo se toma como P
            }


            if(!strcmp(fdiskFit,""))
            {
                strcpy(fdiskFit,"w");         ///si de casualidad no venia fit se toma como W
            }

            if(!strcmp(fdiskDelete,""))
            {
                strcpy(fdiskDelete,"null");         ///si de casualidad no venia delete se toma como NULL
            }

            if(fdiskAdd == 0)
            {
                /// fdiskAdd = 0;         ///si de casualidad no venia delete se toma como NULL
            }




        /**  printf("Los datos para particionar un disco son: \n");
              printf("El tamanio:      %d\n",fdiskSize);
              printf("La ruta:         %s\n",fdiskPath);
              printf("La unidad:       %s\n",fdiskUnit);
              printf("El tipo:         %s\n",fdiskType);
              printf("El ajuste:       %s\n",fdiskFit);
              printf("El delete:       %s\n",fdiskDelete);
              printf("El nombre:       %s\n",fdiskName);
              printf("EL add:          %d\n",fdiskAdd);**/


            printf("\n*******************Formateo de Disco********************\n");

            if(fdiskAdd == 0 && !strcmp(fdiskDelete,"null"))
            {

                //printf("Vamos a crear particion\n");
                int ver = verificarNombreParticion(fdiskName,fdiskPath);
                if(ver == 0)
                {

                    //     printf("No existe el nombre, creamos particion\n");
                    comandoFdisk(fdiskSize, fdiskUnit[0],fdiskPath, fdiskType[0],fdiskFit[0], fdiskName,fdiskDelete,fdiskAdd);

                }
                else if(ver == 1)
                {

                    printf("No pueden haber 2 particiones con el mismo nombre\n");

                }
                else
                {

                    printf("Cree el disco primero\n");
                }

            }
            else if(fdiskAdd != 0 && !strcmp(fdiskDelete,"null"))///procedemos a cambiar espacios
            {
                //printf("cambio de espacios\n");

                int ver = verificarNombreParticion(fdiskName,fdiskPath);
                if(ver == 0)
                {

                    printf("La particion no existe , por lo tanto no se puede redimensionar\n");


                }
                else if(ver == 1)
                {

                    printf("Si existe la particion procedemos  a redimensionar \n");
                    comandoFdisk(fdiskSize, fdiskUnit[0],fdiskPath, fdiskType[0],fdiskFit[0], fdiskName,fdiskDelete,fdiskAdd);


                }
                else
                {
                    printf("Este disco no existe por favor, Cree el disco primero\n");
                }


            }
            else if(strcmp(fdiskDelete,"null") && fdiskAdd == 0)///se procede a eliminar particiones
            {

                //  printf("eliminar particiones\n");

                if(verificarNombreParticion(fdiskName,fdiskPath) == 1)
                {

                    printf("Si existe procedemos a eliminar\n");

                    printf("Desea eliminar la particion %s ??? Y/N\n",fdiskName);
                    char respuesta[3];
                    fgets(&respuesta,3,stdin);
                    printf("Usted ingreso: %s\n",respuesta);
                    if(strstr(respuesta,"y"))
                    {
                        if(!strcmp(fdiskDelete,"fast"))
                        {
                            printf("Eliminamos fast\n");
                            EliminarParticionFast(fdiskName,fdiskPath);

                        }
                        else
                        {
                            printf("Eliminamos full\n");
                            EliminarParticionFull(fdiskName,fdiskPath);

                        }
                    }
                    else if(strstr(respuesta,"n"))
                    {
                        printf("No se elimino la particion...\n");
                    }

                    strcpy(respuesta,"");

                }
                else
                {

                    printf("No podemos eliminar, la particion no existe %s\n",fdiskName);

                }


            }
            else
            {

                printf("Su comando contiene parametros no aptos \n");
            }


            ///leerMBR(fdiskPath);
            fdiskSize =0;
            strcpy(fdiskPath,"");
            strcpy(fdiskUnit,"");
            strcpy(fdiskType,"");
            strcpy(fdiskFit,"");
            strcpy(fdiskDelete,"");
            strcpy(fdiskName,"");
            fdiskAdd = 0;
            add = 0;
            del = 0;
            opc = 0;


            break;



/************************************  COMANDO NO. 4  ****************************************************************************************************/

        case 4:


            if(!strcmp(tokActual,"-path"))
            {
                state = 40;
                opc = 1;
            }
            else if(!strcmp(tokActual,"-name"))
            {
                state = 40;
                opc = 2;
            }else{

                state = 1000;
                printf("Parametro no reconocido \n");
            }


            break;


        case 40:

            if(!strcmp(tokActual,":"))
            {
                state = 41;
            }
            else
            {
                state = 1000;
                printf("Se esperaba : \n");
            }
            break;


        case 41:

            if(!strcmp(tokActual,":"))
            {
                if(opc == 1){

                    state = 42;

                }else if(opc == 2){

                    state = 43;

                }

            }
            else
            {

                state = 1000;
                printf("Se esperaba : \n");
            }
            break;





        case 42:

            if(strlen(tokActual)>0)
            {
                state = 4;
                strcpy(mountPath,tokActual);
            }
            else
            {
                printf("Ingrese un nombre valido \n");
                state=1000;
            }


            break;



        case 43:


            if(strlen(tokActual)>0)
            {
                state = 104;
                x--;
                strcpy(mountName,tokActual);
            }
            else
            {
                printf("Ingrese un nombre valido \n");
                state=1000;
            }


            break;


        case 104:

            //printf("Los datos para montar una particion son:\n");
            //printf("La ruta del disco:      %s\n",mountPath);
            //printf("Nombre de Particion     %s\n",mountName);

            printf("\n****************** Montar particiones *******************\n");
            mount(mountPath,mountName);
            printf("\n--Lista de Particiones Montadas--\n");
            imprimirParticionesMontadas();
            strcpy(mountPath,"");
            strcpy(mountName,"");
            opc = 0;
            break;

/**************************************  COMANDO NO. 5   ********************************************************/


        case 5:                                               ///unmount

            if(!strcmp(tokActual,"-id"))
            {
                state = 44;
            //    printf(" - id es %s\n",tokActual);
            }
            break;


        case 44:

            if(!strcmp(tokActual,":"))
            {
                state = 45;
            }
            else
            {
                state = 1000;
                printf("Se esperaba : \n");
            }
            break;


        case 45:

            if(!strcmp(tokActual,":"))
            {
                    state = 46;
            }
            else
            {

                state = 1000;
                printf("Se esperaba : \n");
            }
            break;




        case 46:

            if(strcmp(tokActual,""))
            {
                state = 105;
                strcpy(unmountid,tokActual);
               /// printf("%s este es \n",unmountid);
                x--;
            }
            else
            {
                printf("Ingrese un nombre valido \n");
                state=1000;
            }


            break;


        case 105:
            printf("\n**************** Desmontar particiones *******************\n");
           /// printf("La id de la particion:      %s\n",unmountid);
            unmount(unmountid);
            strcpy(unmountid,"");
            printf("\n--Lista de Particiones Montadas--\n");
            imprimirParticionesMontadas();
            break;




/************************************COMANDO  NO 6  REPORTES******************************************************************/



        case 19:

            if(!strcmp(tokActual,"-name"))
            {

                state = 47;
                opc = 1;

            }else if(!strcmp(tokActual,"-path"))
            {

                state = 47;
                opc = 2;

            }else if(!strcmp(tokActual,"-id"))
            {

                state = 47;
                opc = 3;

            }else if(!strcmp(tokActual,"+ruta"))
            {

                state = 47;
                opc = 4;

            }

            break;



        case 47:

            if(!strcmp(tokActual,":"))
            {
                state = 48;
            }
            else
            {
                state = 1000;
                printf("Se esperaba : \n");
            }
            break;


        case 48:

            if(!strcmp(tokActual,":"))
            {

                  ///  printf("%d \n",opc);

                switch(opc){

                    case 1:
                        state = 49;
                    break;


                    case 2:
                        state = 50;
                    break;


                    case 3:
                        state = 51;
                    break;


                    case 4:

                        if(reps == 1){
                            state = 52;
                        }else{
                            state = 1000;
                            printf("Parametro +ruta solo para reportes 'ls+i' y 'ls+l' \n") ;
                        }


                    break;



                    default:
                    break;
                }

            }
            else
            {

                state = 1000;
                printf("Se esperaba : \n");
            }
            break;



        case 49:

            if(!strcmp(tokActual,"mbr") || !strcmp(tokActual,"disk") || !strcmp(tokActual,"inode") || !strcmp(tokActual,"journaling") || !strcmp(tokActual,"block") || !strcmp(tokActual,"bm_inode") || !strcmp(tokActual,"bm_block") || !strcmp(tokActual,"tree") || !strcmp(tokActual,"sb") || !strcmp(tokActual,"file") || !strcmp(tokActual,"ls+i") || !strcmp(tokActual,"ls+l"))
            {

                strcpy(repName,tokActual);


                if(!strcmp(repPath,"")  ||!strcmp(repId,"") ){
                    state=19;
                }else if(strcmp(repName,"")  && strcmp(repPath,"")  && strcmp(repId,"")  && x == contadorTokens -1)  {
                    state = 119;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios 1\n");
                    state = 1000;
                }

                if(!strcmp(tokActual,"ls+i") || !strcmp(tokActual,"ls+l")){
                    reps = 1;
                }

            }
            else
            {

                printf("Tipo de reporte no reconocido\n");
                state= 1000;

            }

            break;





        case 50:

            if(strcmp(tokActual,""))
            {

                strcpy(repPath,tokActual);


                if(!strcmp(repName,"")  ||!strcmp(repId,"") ){
                    state=19;
                }else if(strcmp(repName,"")  && strcmp(repPath,"")  && strcmp(repId,"")  && x == contadorTokens -1)  {
                    state = 119;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios 1\n");
                    state = 1000;
                }


            }
            else
            {

                printf("La path no es valida\n");
                state= 1000;

            }

            break;



        case 51:

            if(strcmp(tokActual,""))
            {

                strcpy(repId,tokActual);

                if(!strcmp(repPath,"")  ||!strcmp(repName,"") ){
                    state=19;
                }else if(strcmp(repName,"")  && strcmp(repPath,"")  && strcmp(repId,"")  && x == contadorTokens -1)  {
                    state = 119;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios 1\n");
                    state = 1000;
                }

            }
            else
            {

                printf("El id no es valido\n");
                state= 1000;

            }

            break;


        case 52:

            if(strcmp(tokActual,""))
            {
                state=60;
                strcpy(repRuta,tokActual);

                if(!strcmp(repPath,"")  ||!strcmp(repId,"") ||!strcmp(repName,"") ){
                    state=19;
                }else if(strcmp(repName,"")  && strcmp(repPath,"")  && strcmp(repId,"")  && x == contadorTokens -1)  {
                    state = 119;
                    x--;
                }else if( x == contadorTokens -1 ){
                    printf("Faltan parametros obligatorios 1\n");
                    state = 1000;
                }



            }
            else
            {
                printf("La ruta no es valida\n");
                state= 1000;
            }

            break;




        case 119:


            printf("\n**************** Generacion de Reportes *******************\n");

            for(zz; zz < cantidadParticionesMontadas; zz++)
            {

                if(!strcmp(ParticionesMontadas[zz].id,repId))
                {
                    hallado = 1;
                    break;
                }

            }



            if(hallado == 1)
            {

                // printf("Se hallo el id especificado\n");
                if(!strcmp(repRuta,"") && !strcmp(repName,"ls+i") ||  !strcmp(repRuta,"") && !strcmp(repName,"ls+l") )
                {
                    x--;
                    printf("Se necesita el parametro ruta para este reporte\n");
                    state=1000;

                }
                else
                {

                    particionMontada parti2 = buscarParticion(repId);

                    /**  printf("Los datos para Reportar son:\n");
                      printf("El id:      %s\n",repId);
                      printf("El nombre:  %s\n",repName);
                      printf("El path:    %s\n",repPath);
                      printf("La ruta:    %s\n",repRuta);**/

                    if(!strcmp(repName,"mbr"))
                    {

                        ReporteDeMBR(ParticionesMontadas[zz].pathDisco,repPath);

                    }
                    else if(!strcmp(repName,"disk"))
                    {
                        /// printf("discos \n");
                        ReporteDeParticiones(ParticionesMontadas[zz].pathDisco,repPath);

                    }
                    else if(!strcmp(repName,"sb"))
                    {


                       /// reporteSuperBloque(parti2,repPath);

                    }
                    else if(!strcmp(repName,"bm_avd"))
                    {


                     ///   reporteBitmapAvd(parti2,repPath);

                    }




                }

            }
            else
            {

                printf("El id que especifica no esta montado\n");
            }

            strcpy(repId,"");
            strcpy(repName,"");
            strcpy(repPath,"");
            strcpy(repRuta,"");
            zz=0;
            hallado=0;
            reps = 0;

            break;



        case 20:

            if(!strcmp(tokActual, "-path"))
            {

                state=65;


            }
            else
            {

                state = 1000;

            }

            break;

        case 65:

            if(!strcmp(tokActual, ":"))
            {

                state=66;


            }
            else
            {

                state = 1000;
            }


            break;


        case 66:
            if(strcmp(tokActual, ""))
            {

                state=120;
                strcpy(execPath,tokActual);
                x--;

            }
            else
            {

                state = 1000;
                printf("Ingrese una ruta valida para exec\n");

            }


            break;






        case 250:
            break;


        case 1000:
            printf("Error sintactico\n");
            return;

            break;



        default:
            break;



        }

    }



}


void BorrarPalabra (char *frase, char *palabra)
{

    char copia  [2048]; // Poner la longitud máxima de la frase.
    int i = 0, l, k = 0;
    while (i < strlen (frase))
    {
        if (frase [i] == palabra [0])
        {
            for (l = 0; l < strlen (palabra); l++)
            {
                if (frase [i+ l] != palabra [l])
                    break;
            }
            if (l == strlen (palabra))
                i += strlen (palabra);
        }
        else
        {
            copia [k] = frase [i];
            i++;
            k++;
        }
    }
    copia [k] = '\0';
    strcpy(frase, copia);

}


void exec(char *ruta)
{


    FILE *archivo;
    archivo = fopen(ruta,"r");
    int xxx=0;

    if (archivo == NULL)
        exit(1);

    //printf("\nEl contenido del archivo de prueba es \n\n");
    int xu = 0;
    limpiezaTokens();
    char fy[1000];
     int dod=0;
    while (feof(archivo) == 0)
    {



        char ft[1000];
        fgets(ft,200,archivo);
        fflush(archivo);

        if(dod == 0){

        strcpy(fy,ft);

        }else{

        strcat(fy,ft);

        }



        if(fy[strlen(fy)-2] == '\\'){
            dod = 1;
        }else{
            char fx[1000];
            strcpy(fx,fy);
            analisisLexico(fx);
       ///imprimirTokens(Tokens);
            analisisSintactico(Tokens);
            xu++;
            strcpy(fy,"");
            strcpy(ft,"");
            limpiezaTokens();
            dod = 0;
        }

    }

    fclose(archivo);
    return 0;
}


void inicio()
{

    while(1)
    {
        ingresar();
        analisisLexico(comandoCompleto);
        imprimirTokens(Tokens);
       // analisisSintactico(Tokens);
        limpiezaTokens();
    }

}


#endif // ANALIZADOR_INCLUDED


