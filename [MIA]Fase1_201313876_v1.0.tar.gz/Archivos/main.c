#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include </home/paublo/Proyecto/Archivos/Analizador.h>


/**cosas pendientes:

x1. crear logicas
x2. logicas en reporte grafico
x3. reporte mbr con logicas
4. eliminar particiones,cuando se elimine la particion recordar que en la logica borrar el bit siguiente de la que este antes de la eliminada.
5. aniadir espacio a particiones
x6. generar reportes con los comandos respectivos
x7.nombres de particiones repetidas
x8. leer comandos desde un archivo hueco

*/
int main(void)
{
exec("/home/paublo/Script.txt");
//remove("/home/paublo/archivos/primer practica/d1.dsk");
///inicio();
///exec("/home/paublo/scrip.txt");

    return 0;

}

