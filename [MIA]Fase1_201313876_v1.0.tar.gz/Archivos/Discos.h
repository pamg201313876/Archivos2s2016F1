#ifndef DISCOS_H_INCLUDED
#define DISCOS_H_INCLUDED

int discosTotales = 0;

char NombreParticion1 [100];

typedef struct
{

float numero;

}valorsito;

valorsito aaaa;

struct particionMontada
{

    char id[6];
    char pathDisco[150];
    char nombreParticion[30];
    int byteInicio;
    int tamanio;
    char tipo;
    char montado;///1 si , 0 no

};

typedef struct particionMontada particionMontada;

struct discoMontado
{

    char pathDisco[150];
    int vecesMontado;

};

typedef struct discoMontado discoMontado;

int cantidadDiscosMontados=0;
int cantidadParticionesMontadas=0;
particionMontada ParticionesMontadas[50];   ///aca guardamos las particiones montadas
discoMontado DiscosMontados[10];            ///aca guardamos los discos montados


struct particion
{

    char particion_status;
    char part_type;
    char part_fit;
    int part_start;
    int part_size;
    char part_name[16] ;

};

typedef struct particion particion;


struct MBRdisco
{

    char nombre[32];
    int mbr_tamanio;
    time_t mbr_fecha_creacion;
    int mbr_disk_signature;
    particion mbr_partition_1;
    particion mbr_partition_2;
    particion mbr_partition_3;
    particion mbr_partition_4;

};


struct EBR
{

    char part_status;
    char part_fit;
    int part_start;
    int part_size;
    int part_next;
    char part_name[16];

};


typedef struct EBR EBR;
typedef struct MBRdisco MBRdisco;



void MBR(char *ruta, int tamanio)
{

    MBRdisco nuevo;
    nuevo.mbr_tamanio = tamanio;
    nuevo.mbr_fecha_creacion = time(0);
    nuevo.mbr_disk_signature = discosTotales;

    nuevo.mbr_partition_1.particion_status = '0';
    nuevo.mbr_partition_2.particion_status = '0';
    nuevo.mbr_partition_3.particion_status = '0';
    nuevo.mbr_partition_4.particion_status = '0';

    nuevo.mbr_partition_1.part_start = -1;
    nuevo.mbr_partition_2.part_start = -1;
    nuevo.mbr_partition_3.part_start = -1;
    nuevo.mbr_partition_4.part_start = -1;

    FILE *arch=fopen(ruta,"rb+");



    if (arch!=NULL)
    {
        fseek(arch,0,SEEK_SET);
        fwrite(&nuevo,sizeof(MBRdisco),1,arch);
        //printf("MBR exitoso en el Disco de la RUta %s\n",ruta);
    }
    else
    {
        printf("Error Al Imprimir El mbr");
    }

    fclose(arch);
    printf("Disco Creado existosamente en: %s \n",ruta);
    ///leerMBR(ruta);


}



void leerMBR(char *ruta) ///while logicas pendiente
{




    FILE *arch = fopen(ruta,"rb");
    if (arch!=NULL)
    {


        MBRdisco lectura;
        EBR EBRleida;


        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);

        struct tm *tlocal = localtime(&lectura.mbr_fecha_creacion);
        char output[128];
        strftime(output,128,"%d/%m/%y %H:%M:%S",tlocal);


        printf("MBR Signature: %d \n",lectura.mbr_disk_signature);
        printf("MBR Size: %d \n",lectura.mbr_tamanio);
        printf("MBR Date/Hour: %s\n",output);


        if(lectura.mbr_partition_1.part_start != -1 && lectura.mbr_partition_1.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            printf("\nParticion 1:\n");
            printf("    Estado de la particion: %c\n",lectura.mbr_partition_1.particion_status);
            printf("    Tipo de particion:      %c\n",lectura.mbr_partition_1.part_type);
            printf("    Tipo de Ajuste:         %c\n",lectura.mbr_partition_1.part_fit);
            printf("    Byte de Inicio:         %d\n",lectura.mbr_partition_1.part_start);
            printf("    Tamanio de Particion:   %d\n",lectura.mbr_partition_1.part_size);
            printf("    Nombre de Particion:    %s\n",lectura.mbr_partition_1.part_name);

            if(lectura.mbr_partition_1.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_1.part_start;

                while(Leer != -1)
                {
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    printf("        Particion Extendida:\n");
                    printf("            Estado de la particion:     %c\n",EBRleida.part_status);
                    printf("            Tipo de Ajuste:             %c\n",EBRleida.part_fit);
                    printf("            Byte de Inicio:             %d\n",EBRleida.part_start);
                    printf("            Tamanio de Particion:       %d\n",EBRleida.part_size);
                    printf("            Byte de la siguiente:       %d\n",EBRleida.part_next);
                    printf("            Nombre de Particion:        %s\n",EBRleida.part_name);
                    Leer = EBRleida.part_next;
                    char sad[1000];
                    fgets(&sad,1000,stdin);
                }

            }

        }


        if(lectura.mbr_partition_2.part_start != -1 && lectura.mbr_partition_2.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            printf("\nParticion 2:\n");
            printf("    Estado de la particion: %c\n",lectura.mbr_partition_2.particion_status);
            printf("    Tipo de particion:      %c\n",lectura.mbr_partition_2.part_type);
            printf("    Tipo de Ajuste:         %c\n",lectura.mbr_partition_2.part_fit);
            printf("    Byte de Inicio:         %d\n",lectura.mbr_partition_2.part_start);
            printf("    Tamanio de Particion:   %d\n",lectura.mbr_partition_2.part_size);
            printf("    Nombre de Particion:    %s\n",lectura.mbr_partition_2.part_name);

            if(lectura.mbr_partition_2.part_type == 'e')
            {
                int Leer = lectura.mbr_partition_2.part_start;

                while(Leer != -1)
                {
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    printf("        Particion Extendida:\n");
                    printf("            Estado de la particion:     %c\n",EBRleida.part_status);
                    printf("            Tipo de Ajuste:             %c\n",EBRleida.part_fit);
                    printf("            Byte de Inicio:             %d\n",EBRleida.part_start);
                    printf("            Tamanio de Particion:       %d\n",EBRleida.part_size);
                    printf("            Byte de la siguiente:       %d\n",EBRleida.part_next);
                    printf("            Nombre de Particion:        %s\n",EBRleida.part_name);
                    Leer = EBRleida.part_next;
                }

            }

        }

        if(lectura.mbr_partition_3.part_start != -1 && lectura.mbr_partition_3.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            printf("\nParticion 3:\n");
            printf("    Estado de la particion: %c\n",lectura.mbr_partition_3.particion_status);
            printf("    Tipo de particion:      %c\n",lectura.mbr_partition_3.part_type);
            printf("    Tipo de Ajuste:         %c\n",lectura.mbr_partition_3.part_fit);
            printf("    Byte de Inicio:         %d\n",lectura.mbr_partition_3.part_start);
            printf("    Tamanio de Particion:   %d\n",lectura.mbr_partition_3.part_size);
            printf("    Nombre de Particion:    %s\n",lectura.mbr_partition_3.part_name);

            if(lectura.mbr_partition_3.part_type == 'e')
            {
                int Leer = lectura.mbr_partition_3.part_start;

                while(Leer != -1)
                {
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    printf("        Particion Extendida:\n");
                    printf("            Estado de la particion:     %c\n",EBRleida.part_status);
                    printf("            Tipo de Ajuste:             %c\n",EBRleida.part_fit);
                    printf("            Byte de Inicio:             %d\n",EBRleida.part_start);
                    printf("            Tamanio de Particion:       %d\n",EBRleida.part_size);
                    printf("            Byte de la siguiente:       %d\n",EBRleida.part_next);
                    printf("            Nombre de Particion:        %s\n",EBRleida.part_name);
                    Leer = EBRleida.part_next;
                }

            }

        }

        if(lectura.mbr_partition_4.part_start != -1 && lectura.mbr_partition_4.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            printf("\nParticion 4:\n");
            printf("    Estado de la particion: %c\n",lectura.mbr_partition_4.particion_status);
            printf("    Tipo de particion:      %c\n",lectura.mbr_partition_4.part_type);
            printf("    Tipo de Ajuste:         %c\n",lectura.mbr_partition_4.part_fit);
            printf("    Byte de Inicio:         %d\n",lectura.mbr_partition_4.part_start);
            printf("    Tamanio de Particion:   %d\n",lectura.mbr_partition_4.part_size);
            printf("    Nombre de Particion:    %s\n",lectura.mbr_partition_4.part_name);

            if(lectura.mbr_partition_4.part_type == 'e')
            {
                int Leer = lectura.mbr_partition_4.part_start;

                while(Leer != -1)
                {
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    printf("        Particion Extendida:\n");
                    printf("            Estado de la particion:     %c\n",EBRleida.part_status);
                    printf("            Tipo de Ajuste:             %c\n",EBRleida.part_fit);
                    printf("            Byte de Inicio:             %d\n",EBRleida.part_start);
                    printf("            Tamanio de Particion:       %d\n",EBRleida.part_size);
                    printf("            Byte de la siguiente:       %d\n",EBRleida.part_next);
                    printf("            Nombre de Particion:        %s\n",EBRleida.part_name);
                    Leer = EBRleida.part_next;
                }

            }


        }

    }
    else
    {
        printf("Error en Lectura del MBR  %s\n",ruta);

        return;
    }
    fclose(arch);


}


void crearDisco(int tamanio,char* ruta,char* nombre, char* unidad)
{


    char comand1[200];
    strcpy(comand1,"mkdir -p ");
    strcat(comand1,"\"");
    strcat(comand1,ruta);
    strcat(comand1,"\"");

    char comand2[200];
    strcpy(comand2,"rm -fr ");
    strcat(comand2,"\"");
    strcat(comand2,ruta);
    strcat(comand2,"\"");

    system(comand1);
   /// system(comand2);


       int multi=1;

        int tamanioOficial=0;

        if(!strcmp(unidad,"k"))
        {
            multi=1;
            //  printf("k\n");
            tamanioOficial= tamanio*1024;
        }
        else if(!strcmp(unidad,"m"))
        {
            multi=1024;
            //printf("m\n");
            tamanioOficial= 1024*1024*tamanio;
        }
        else
        {
            //printf("b\n");
            tamanioOficial= tamanio;
        }

   // printf("%s\n",unidad);

    char comand3[200];
    strcpy(comand3,ruta);
    strcat(comand3,nombre);


    int iteraciones= multi;
    char *j;

    FILE *arch=fopen(comand3,"wb+");


    if (arch!=NULL)
    {
        int x=0;

        if(strcmp(unidad,"b")){
      //       printf("bytesssss\n");
            for(x=0; x<tamanioOficial; x++)
            {
                fwrite(&j,sizeof(char),1,arch);
            }
        }else{

   //     printf("byte\n");
             for(x=0; x<tamanioOficial; x++)
            {
                fwrite(&j,sizeof(char),1,arch);
            }
        }

    }
    else
    {
        printf("Error");
    }

    discosTotales++;
    fclose(arch);
    MBR(comand3,multi*1024*tamanio);                    ///imprimimos su mbr



}



void borrarDisco(char* ruta)
{

    char rut[150];

    //strcpy(rut,"\"");
    strcpy(rut,ruta);
    //strcat(rut,"\"");
    FILE *arch = fopen(rut,"r");
  ///  printf("%s\n",rut);

    if (arch!=NULL)
    {

        printf("Eliminando disco.... \n");
        remove(ruta);
        printf("Disco Elminado!! \n");

    }
    else
    {

        printf("Este disco no existe!! \n");
    }


}



void comandoFdisk(int tamanio,char unidad, char*ruta,char type,char fit,char *nombre,char *delet, int add)
{

    if(!strcmp(delet,"null") && add == 0)                               ///creacion de particiones
    {



        crearParticion(tamanio,unidad,ruta,type,fit,nombre);

    }
    else if(add != 0)                                               ///aniade tamanio
    {

        RedimensionarParticiones(unidad,add,nombre,ruta);

    }

}



void crearParticion(int tamanio, char unidad, char *ruta, char type, char fit, char* nombre)
{

    ///printf("Disco a particionar %s %s\n",ruta,nombre);

    int totalParticiones =          0;///primarias y extendidas
    int particionesLogicas =        0;
    int particionesExtendidas =     0;
    int particionesPrimarias =      0;

    ///estas las vamos a usar para calcular el byte de inicio de la particion nueva
    int inicio1 = -1;
    int tamanio1= -1;
    int inicio2= -1;
    int tamanio2= -1;
    int inicio3= -1;
    int tamanio3= -1;
    int inicio4= -1;
    int tamanio4= -1;
    int fin1= -1;
    int fin2= -1;
    int fin3= -1;
    int fin4= -1;

    int Pos = -1;

    int inicioExtendida;
    int TamanioExtendida;

    FILE *arch = fopen(ruta,"rb+");

    if (arch!=NULL)
    {


        MBRdisco lectura;
        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);

        /** con este codigo vamos recorriendo las particiones del mbr y vamos sacando los totales numericos de particiones*/

        if(lectura.mbr_partition_1.particion_status == '1')
        {
            //printf("1 con nombre %s \n",lectura.mbr_partition_1.part_name);
            totalParticiones++;
            tamanio1=lectura.mbr_partition_1.part_size;
            inicio1=lectura.mbr_partition_1.part_start;
            fin1=inicio1+tamanio1;
            if(lectura.mbr_partition_1.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_1.part_type=='e')
            {
                particionesExtendidas++;
                inicioExtendida = lectura.mbr_partition_1.part_start;
                TamanioExtendida=lectura.mbr_partition_1.part_size;
            }
        }

        if(lectura.mbr_partition_2.particion_status == '1')
        {
            // printf("2 con nombre %s \n",lectura.mbr_partition_2.part_name);
            totalParticiones++;
            tamanio2=lectura.mbr_partition_2.part_size;
            inicio2=lectura.mbr_partition_2.part_start;
            fin2=inicio2+tamanio2;
            if(lectura.mbr_partition_2.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_2.part_type=='e')
            {

                inicioExtendida = lectura.mbr_partition_2.part_start;
                TamanioExtendida=lectura.mbr_partition_2.part_size;
                particionesExtendidas++;
            }
        }

        if(lectura.mbr_partition_3.particion_status == '1')
        {
            // printf("3 con nombre %s \n",lectura.mbr_partition_3.part_name);
            totalParticiones++;
            tamanio3=lectura.mbr_partition_3.part_size;
            inicio3=lectura.mbr_partition_3.part_start;
            fin3=inicio3+tamanio3;
            if(lectura.mbr_partition_3.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_3.part_type=='e')
            {
                inicioExtendida = lectura.mbr_partition_3.part_start;
                TamanioExtendida=lectura.mbr_partition_3.part_size;
                particionesExtendidas++;
            }
        }

        if(lectura.mbr_partition_4.particion_status == '1')
        {
            //printf("4 con nombre %s \n",lectura.mbr_partition_4.part_name);
            totalParticiones++;
            tamanio4=lectura.mbr_partition_4.part_size;
            inicio4=lectura.mbr_partition_4.part_start;
            fin4=inicio4+tamanio4;
            if(lectura.mbr_partition_4.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_4.part_type=='e')
            {
                inicioExtendida = lectura.mbr_partition_4.part_start;
                TamanioExtendida=lectura.mbr_partition_4.part_size;
                particionesExtendidas++;
            }
        }



        int multi=1;

        int tamanioOficial=0;

        if(unidad == 'k')
        {
            multi=1;
            //  printf("k\n");
            tamanioOficial= tamanio*1024;
        }
        else if(unidad == 'm')
        {
            multi=1024;
            //printf("m\n");
            tamanioOficial= 1024*1024*tamanio;
        }
        else
        {
            //printf("b\n");
            tamanioOficial= tamanio;
        }

        // printf("El tamanio oficial de esta es: %d %d %d",tamanioOficial,tamanio,multi);
        /** despues de sacar los totales de particiones vamos a ver las validaciones  */




        if(totalParticiones < 4 && type != 'l')                                                ///veamos si hay menos de 4 particiones entre primarias y extendidas
        {

            /** necesitamos calcular el byte de inicio de la particion */

            int byteInicio=0;




            if(totalParticiones==0)                                                 ///sino hay particiones entonces vamos a tomar como inicio justo despues del mbr
            {

                //printf("no hay particiones we \n");
                if( (lectura.mbr_tamanio-sizeof(MBRdisco)) >= tamanioOficial )
                {

                    byteInicio = sizeof(MBRdisco);                                      ///tamanio en -1 representa que no esta activa esa particion

                }
                else
                {

                    printf("Excede la capacidad del disco\n");
                    fclose(arch);
                    return;
                }


            }
            else if(totalParticiones==1)                                            ///si  hay 1 particion: entonces necesitamos cual es la particion que esta creada
            {
                // printf("1 particion hay \n");

                if(tamanio1 != -1)                                                  ///despues, vamos a calcular donde hay espacio para nuestra particion, si antes de la ya creada o despues
                {

                    if((inicio1-sizeof(MBRdisco)) >= (tamanioOficial))           ///si el inicio de la creada-mbr es mayor o igual se imprime antes de la creada
                    {

                        byteInicio = sizeof(MBRdisco);

                    }
                    else if((lectura.mbr_tamanio - fin1) >= (tamanioOficial))    ///sino entonces se verifica que el tamanio del disco - el fin de la primera sea mayor o igual par apoder imprimr despues
                    {

                        byteInicio = fin1;

                    }
                    else
                    {

                        printf("Lo sentimos pero no hay espacio en el disco para crear su particion\n"); ///sino pues no se puede
                        fclose(arch);
                        return;

                    }

                }
                else if(tamanio2 != -1)
                {


                    if((inicio2-sizeof(MBRdisco)) >= (tamanioOficial))           ///si el inicio de la creada-mbr es mayor o igual se imprime antes de la creada
                    {

                        byteInicio = sizeof(MBRdisco);

                    }
                    else if((lectura.mbr_tamanio - fin2) >= (tamanioOficial))    ///sino entonces se verifica que el tamanio del disco - el fin de la primera sea mayor o igual par apoder imprimr despues
                    {

                        byteInicio = fin2;

                    }
                    else
                    {

                        printf("Lo sentimos pero no hay espacio en el disco para crear su particion\n"); ///sino pues no se puede
                        fclose(arch);
                        return;

                    }

                }
                else if(tamanio3 != -1)
                {

                    if((inicio3-sizeof(MBRdisco)) >= (tamanioOficial))           ///si el inicio de la creada-mbr es mayor o igual se imprime antes de la creada
                    {

                        byteInicio = sizeof(MBRdisco);

                    }
                    else if((lectura.mbr_tamanio - fin3) >= (tamanioOficial))    ///sino entonces se verifica que el tamanio del disco - el fin de la primera sea mayor o igual par apoder imprimr despues
                    {

                        byteInicio = fin3;

                    }
                    else
                    {

                        printf("Lo sentimos pero no hay espacio en el disco para crear su particion\n"); ///sino pues no se puede
                        fclose(arch);
                        return;

                    }


                }
                else if(tamanio4 != -1)
                {

                    if((inicio4-sizeof(MBRdisco)) >= (tamanioOficial))           ///si el inicio de la creada-mbr es mayor o igual se imprime antes de la creada
                    {

                        byteInicio = sizeof(MBRdisco);

                    }
                    else if((lectura.mbr_tamanio - fin4) >= (tamanioOficial))    ///sino entonces se verifica que el tamanio del disco - el fin de la primera sea mayor o igual par apoder imprimr despues
                    {

                        byteInicio = fin4;

                    }
                    else
                    {

                        printf("Lo sentimos pero no hay espacio en el disco para crear su particion\n"); ///sino pues no se puede
                        fclose(arch);
                        return;

                    }

                }


            }
            else if(totalParticiones==2)                                            ///si hay 2 buscamos espacios antes de la primera , entre ambas, y al final de la 2da
            {
                // printf("2 particion hay \n");

                if(tamanio1 != -1 && tamanio2 != -1)
                {

                    if(inicio1 < inicio2)                                                   ///la particion 1 esta antes que la 2
                    {

                        if((inicio1-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 1 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);

                        }
                        else if((inicio2 - fin1) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin1;

                        }
                        else if((lectura.mbr_tamanio-fin2) >= (tamanioOficial) )        ///si despues de la particion 2 hay espacio para meter la particion
                        {

                            byteInicio = fin2;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio2 < inicio1)                                      ///la particion 2 esta antes que la 1
                    {


                        if((inicio2-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 2 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1 - fin2) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin2;

                        }
                        else if((lectura.mbr_tamanio-fin1) >= (tamanioOficial) )        ///si despues de la particion 1 hay espacio para meter la particion
                        {

                            byteInicio = fin1;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }

                }
                else if(tamanio1 != -1 && tamanio3 != -1)
                {

                    if(inicio1 < inicio3)                                                   ///la particion 1 esta antes que la 3
                    {

                        if((inicio1-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 1 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);

                        }
                        else if((inicio3 - fin1) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin1;

                        }
                        else if((lectura.mbr_tamanio-fin3) >= (tamanioOficial) )        ///si despues de la particion 3 hay espacio para meter la particion
                        {

                            byteInicio = fin3;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio3 < inicio1)                                      ///la particion 3 esta antes que la 1
                    {


                        if((inicio3-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 3 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin3) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin3;

                        }
                        else if((lectura.mbr_tamanio-fin1) >= (tamanioOficial) )        ///si despues de la particion 1 hay espacio para meter la particion
                        {

                            byteInicio = fin1;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }

                }
                else if(tamanio1 != -1 && tamanio4 != -1)
                {

                    if(inicio1 < inicio4)                                                   ///la particion 1 esta antes que la 4
                    {

                        if((inicio1-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 1 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);

                        }
                        else if((inicio4 - fin1) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin1;

                        }
                        else if((lectura.mbr_tamanio-fin4) >= (tamanioOficial) )        ///si despues de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio = fin4;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio4 < inicio1)                                              ///la particion 4 esta antes que la 1
                    {


                        if((inicio4-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);
                        }
                        else if((inicio1 - fin4) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin4;

                        }
                        else if((lectura.mbr_tamanio-fin1) >= (tamanioOficial) )        ///si despues de la particion 1 hay espacio para meter la particion
                        {

                            byteInicio = fin1;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }

                }
                else if(tamanio2 != -1 && tamanio3 != -1)
                {

                    if(inicio2 < inicio3)                                                   ///la particion 2 esta antes que la 3
                    {

                        if((inicio2-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 2 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);

                        }
                        else if((inicio3-fin2) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin2;

                        }
                        else if((lectura.mbr_tamanio-fin3) >= (tamanioOficial) )        ///si despues de la particion 3 hay espacio para meter la particion
                        {

                            byteInicio = fin3;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio3 < inicio2)                                              ///la particion 3 esta antes que la 2
                    {


                        if((inicio3-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 3 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin3) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin3;

                        }
                        else if((lectura.mbr_tamanio-fin2) >= (tamanioOficial) )        ///si despues de la particion 2 hay espacio para meter la particion
                        {

                            byteInicio = fin2;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }


                }
                else if(tamanio2 != -1 && tamanio4 != -1)
                {
                    printf("2 y 4 \n");

                    if(inicio2 < inicio4)                                                   ///la particion 2 esta antes que la 4
                    {
                        printf("2 , 4\n");


                        if((inicio2-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 2 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);
                            printf("va entre mbr y part %d %d\n",inicio2-sizeof(MBRdisco),(tamanioOficial) );

                        }
                        else if((inicio4-fin2) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {


                            byteInicio = fin2;
                            printf("va entre ambas %d %d \n",inicio4-fin2,(tamanioOficial) );
                        }
                        else if((lectura.mbr_tamanio-fin4) >= (tamanioOficial) )        ///si despues de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio = fin4;
                            printf("va despues %d %d\n",lectura.mbr_tamanio-fin4,(tamanioOficial) );

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio4 < inicio2)                                              ///la particion 4 esta antes que la 2
                    {


                        if((inicio4-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin4) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin4;

                        }
                        else if((lectura.mbr_tamanio-fin2) >= (tamanioOficial) )        ///si despues de la particion 2 hay espacio para meter la particion
                        {

                            byteInicio = fin2;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }


                }
                else if(tamanio3 != -1 && tamanio4 != -1)
                {

                    if(inicio3 < inicio4)                                                   ///la particion 3 esta antes que la 4
                    {

                        if((inicio3-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 3 y el mbr hay espacio para meter la particion
                        {

                            byteInicio = sizeof(MBRdisco);

                        }
                        else if((inicio4-fin3) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin3;

                        }
                        else if((lectura.mbr_tamanio-fin4) >= (tamanioOficial) )        ///si despues de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio = fin4;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }
                    else if(inicio4 < inicio3)                                              ///la particion 4 esta antes que la 2
                    {


                        if((inicio4-sizeof(MBRdisco)) >= (tamanioOficial) )             ///si antes de la particion 4 hay espacio para meter la particion
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3 - fin4) >= (tamanioOficial) )                  ///si entre ambas particiones hay espacio
                        {

                            byteInicio = fin4;

                        }
                        else if((lectura.mbr_tamanio-fin3) >= (tamanioOficial) )        ///si despues de la particion 2 hay espacio para meter la particion
                        {

                            byteInicio = fin3;

                        }
                        else                                                                ///sino pues no se puede
                        {

                            printf("No hay espacio para crear la particion\n");
                            fclose(arch);
                            return;

                        }

                    }

                }


            }
            else if(totalParticiones==3)                                            ///si hay 3 particiones vemos el orden y buscamos espacios antes , enmedio y al final de ellas
            {

                // printf("HAY 3 PARTICIONES YA \n");

                if(tamanio1 == -1)                                                          ///las particiones ocupadas son 2,3,4
                {
                    printf("1 desocupada\n");

                    if(inicio2<inicio3 && inicio3<inicio4)                                             ///abc
                    {

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;

                        }
                        else if((inicio4-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;

                        }

                    }
                    else if(inicio2<inicio4 && inicio4<inicio3)                                        ///acb
                    {

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;

                        }
                        else if((inicio3-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                        }

                    }
                    else if(inicio3<inicio2 && inicio2<inicio4)                                        ///bac
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio4-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;

                        }

                    }
                    else if(inicio3<inicio4 && inicio4<inicio2)                                        ///bca
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio2-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }

                    }
                    else if(inicio4<inicio2 && inicio2<inicio3)                                        ///cab
                    {

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio3-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                        }

                    }
                    else if(inicio4<inicio3 && inicio3<inicio2)                                        ///cba
                    {

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio2-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }

                    }



                }
                else if(tamanio2 == -1)                                                     ///las particiones ocupadas son 1,3,4
                {
                    printf("2 desocupada\n");

                    if(inicio1<inicio3 && inicio3<inicio4)                                             ///abc
                    {

                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                        }
                        else if((inicio4-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;

                        }

                    }
                    else if(inicio1<inicio4 && inicio4<inicio3)                                        ///acb
                    {

                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                        }
                        else if((inicio3-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                        }

                    }
                    else if(inicio3<inicio1 && inicio1<inicio4)                                        ///bac
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio4-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin1;

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;

                        }

                    }
                    else if(inicio3<inicio4 && inicio4<inicio1)                                        ///bca
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio1-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }

                    }
                    else if(inicio4<inicio1 && inicio1<inicio3)                                        ///cab
                    {

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio3-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin1;

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                        }

                    }
                    else if(inicio4<inicio3 && inicio3<inicio1)                                        ///cba
                    {

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio1-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }

                    }



                }
                else if(tamanio3 == -1)                                                     ///las particiones ocupadas son 1,2,4
                {

                    printf("la 3 desocupada \n");

                    if(inicio1<inicio2 && inicio2<inicio4)                                             ///abc
                    {

                        printf("1 2 4 %d %d %d \n",inicio1,inicio2,inicio4);


                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                        }
                        else if((inicio4-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;

                        }

                    }
                    else if(inicio1<inicio4 && inicio4<inicio2)                                        ///acb
                    {
                        printf("142 \n");

                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                        }
                        else if((inicio2-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }

                    }
                    else if(inicio2<inicio1 && inicio1<inicio4)                                        ///bac
                    {
                        printf("2,1,4 \n");

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);
                            printf("1 %d %d\n",inicio2-sizeof(MBRdisco),tamanioOficial);

                        }
                        else if((inicio1-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;
                            printf("2 %d %d\n",inicio1-fin2,tamanioOficial);

                        }
                        else if((inicio4-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin1;
                            printf("3 %d %d\n",inicio4-fin1,tamanioOficial);

                        }
                        else if((lectura.mbr_tamanio-fin4)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin4;
                            printf("4 %d %d\n",lectura.mbr_tamanio-fin4,tamanioOficial);

                        }

                    }
                    else if(inicio2<inicio4 && inicio4<inicio1)                                        ///bca
                    {

                        printf("241 \n");

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio4-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;

                        }
                        else if((inicio1-fin4) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin4;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }

                    }
                    else if(inicio4<inicio1 && inicio1<inicio2)                                        ///cab
                    {
                        printf("412 \n");

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio2-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }

                    }
                    else if(inicio4<inicio2 && inicio2<inicio1)                                        ///cba
                    {
                        printf("421 \n");

                        if((inicio4-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin4) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin4;

                        }
                        else if((inicio1-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }

                    }

                }
                else if(tamanio4 == -1)                                                     ///las particiones ocupadas son 1,2,3
                {
                    /// printf("Ultima  disponible \n");

                    if(inicio1<inicio2 && inicio2<inicio3)                                             ///abc
                    {

                        //printf("va al final del disco %d\n");

                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);



                        }
                        else if((inicio2-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                            //printf("despues de todas las particione3\n");
                        }
                        else if((inicio3-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                            //    printf("despues de todas las particiones2\n");

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                            //   printf("despues de todas las particiones4 %d %d\n",(inicio1-sizeof(MBRdisco)), tamanioOficial);
                        }
                        else
                        {

                            printf("No existe espacio para crear la particion \n");
                            return;

                        }

                    }
                    else if(inicio1<inicio3 && inicio3<inicio2)                                        ///acb
                    {

                        if((inicio1-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin1) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin1;

                        }
                        else if((inicio2-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }
                        else
                        {

                            printf("No existe espacio para crear la particion\n");
                            return;

                        }


                    }
                    else if(inicio2<inicio1 && inicio1<inicio3)                                        ///bac
                    {

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;

                        }
                        else if((inicio3-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin1;

                        }
                        else if((lectura.mbr_tamanio-fin3)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin3;

                        }
                        else
                        {

                            printf("No existe espacio para crear la particion\n");
                            return;

                        }


                    }
                    else if(inicio2<inicio3 && inicio3<inicio1)                                        ///bca
                    {

                        if((inicio2-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio3-fin2) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin2;

                        }
                        else if((inicio1-fin3) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin3;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }
                        else
                        {

                            printf("No existe espacio para crear la particion\n");
                            return;

                        }


                    }
                    else if(inicio3<inicio1 && inicio1<inicio2)                                        ///cab
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio1-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio2-fin1) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin2)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin2;

                        }
                        else
                        {

                            printf("No existe espacio para crear la particion\n");
                            return;

                        }


                    }
                    else if(inicio3<inicio2 && inicio2<inicio1)                                        ///cba
                    {

                        if((inicio3-sizeof(MBRdisco)) >= tamanioOficial)                ///despues de mbr y antes de particion1
                        {

                            byteInicio=sizeof(MBRdisco);

                        }
                        else if((inicio2-fin3) >= tamanioOficial)                     ///entre la 1 y 2
                        {

                            byteInicio=fin3;

                        }
                        else if((inicio1-fin2) >= tamanioOficial)                     ///entre la 2 y 3
                        {

                            byteInicio=fin2;

                        }
                        else if((lectura.mbr_tamanio-fin1)>=tamanioOficial)           ///al final del disco
                        {

                            byteInicio=fin1;

                        }
                        else
                        {

                            printf("No existe espacio para crear la particion\n");
                            return;

                        }


                    }

                }

            }


            /**Pnemos los valores que va llevar la nueva particion en el MBR*/


            if(lectura.mbr_partition_1.particion_status == '0')
            {

                lectura.mbr_partition_1.particion_status='1';
                lectura.mbr_partition_1.part_type=type;
                lectura.mbr_partition_1.part_fit=fit;
                lectura.mbr_partition_1.part_start=byteInicio;
                lectura.mbr_partition_1.part_size=tamanioOficial;
                strcpy(lectura.mbr_partition_1.part_name,nombre);

            }
            else if(lectura.mbr_partition_2.particion_status == '0')
            {

                lectura.mbr_partition_2.particion_status='1';
                lectura.mbr_partition_2.part_type=type;
                lectura.mbr_partition_2.part_fit=fit;
                lectura.mbr_partition_2.part_start=byteInicio;
                lectura.mbr_partition_2.part_size=tamanioOficial;
                strcpy(lectura.mbr_partition_2.part_name,nombre);

            }
            else if(lectura.mbr_partition_3.particion_status == '0')
            {

                lectura.mbr_partition_3.particion_status='1';
                lectura.mbr_partition_3.part_type=type;
                lectura.mbr_partition_3.part_fit=fit;
                lectura.mbr_partition_3.part_start=byteInicio;
                lectura.mbr_partition_3.part_size=tamanioOficial;
                strcpy(lectura.mbr_partition_3.part_name,nombre);

            }
            else if(lectura.mbr_partition_4.particion_status == '0')
            {

                lectura.mbr_partition_4.particion_status='1';
                lectura.mbr_partition_4.part_type=type;
                lectura.mbr_partition_4.part_fit=fit;
                lectura.mbr_partition_4.part_start=byteInicio;
                lectura.mbr_partition_4.part_size=tamanioOficial;
                strcpy(lectura.mbr_partition_4.part_name,nombre);

            }

            /** ahora vamos a ver que tipo de particion se nos solicita */

            if(type=='p')                                                     ///Es una primaria
            {

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                printf("Particion %s Primaria Creada Exitosamente!!!\n",nombre);
                fclose(arch);
                return;

            }
            else if(type=='e'  && particionesExtendidas < 1)                  ///Es una extendida
            {

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                EBR nuevoEBR;
                nuevoEBR.part_status = '0';
                nuevoEBR.part_fit = ' ';
                nuevoEBR.part_start = -1;
                nuevoEBR.part_size = -1;
                nuevoEBR.part_next = -1;
                strcpy(nuevoEBR.part_name,"");
                fseek(arch,byteInicio,SEEK_SET);
                fwrite(&nuevoEBR,sizeof(EBR),1,arch);
                printf("Particion Extendida %s Creada Exitosamente!!!\n",nombre);
                fclose(arch);
                return;




            }
            else
            {

                printf("No pueden haber mas de 1 extendida\n");
                fclose(arch);
                return;

            }///recordar agregar las logicas y tambien ver sus nombres


        }
        else if(type == 'l' )
        {

            //printf("Creacion de una logica\n");

            if(particionesExtendidas == 1)
            {

                EBR EBRleida;
                int next = 0;
                int inicioLogica = inicioExtendida;
                int ebrLeidas = 0;
                int siguienteDeAnterior=-1;
                char estado = ' ';

                while(next != -1 )
                {


                    /**leo el ebr*/
                    fseek(arch,inicioLogica,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);

                    ebrLeidas ++;
                    next = EBRleida.part_next;
                    estado = EBRleida.part_status;

                    if(estado == '1' || estado == '0' && ebrLeidas == 1)
                    {
                        inicioLogica = EBRleida.part_next;
                        //  printf("Se sumo aca1\n");
                    }


                    if(next != -1)
                    {
                        //printf("Se sumo aca2\n");

                        if( (EBRleida.part_next - (EBRleida.part_start + EBRleida.part_size)) >= tamanioOficial )
                        {

                            inicioLogica = (EBRleida.part_start + EBRleida.part_size);
                            siguienteDeAnterior = EBRleida.part_next;


                            break;

                        }

                    }
                    else if(next == -1)
                    {
                        // printf("Se sumo aca3\n");
                        if( ((inicioExtendida+TamanioExtendida) - (EBRleida.part_start + EBRleida.part_size))  >= tamanioOficial )
                        {

                            inicioLogica = (EBRleida.part_start + EBRleida.part_size);
                            siguienteDeAnterior = EBRleida.part_next;
                            break;

                        }
                        else
                        {

                            printf("No hay espacio para crear la particion logica\n");
                            return;

                        }
                    }



                }


///                siguienteDeAnterior = EBRleida.part_next;

                EBR nuevoEBR;
                nuevoEBR.part_status = '1';
                nuevoEBR.part_fit = fit;
                nuevoEBR.part_size = tamanioOficial;
                strcpy(nuevoEBR.part_name,nombre);
                nuevoEBR.part_next = siguienteDeAnterior;


                if(EBRleida.part_start == -1 && ebrLeidas == 1)
                {
                    ///es la primera ebr limpia
                    nuevoEBR.part_start = inicioExtendida;
                    fseek(arch,inicioExtendida,SEEK_SET);
                    fwrite(&nuevoEBR,sizeof(EBR),1,arch);

                }
                else
                {

                    /**reescribo la ebr leida poruqe ahroa va tener un next distinto*/
                    EBRleida.part_next = inicioLogica;
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);

                    /**  printf("EBRleida: \n");
                      printf("Ebleida next   %d\n",EBRleida.part_next);
                      printf("Ebleida size   %d\n",EBRleida.part_size);
                      printf("Ebleida staart %d\n",EBRleida.part_start);
                      printf("Ebleida status %c\n",EBRleida.part_status);**/


                    /**ahora escribimos la nueva en el punto indicado y apuntando a la particion que antes apuntaba la otra que esta antes*/
                    nuevoEBR.part_start=inicioLogica;
                    fseek(arch,inicioLogica,SEEK_SET);
                    fwrite(&nuevoEBR,sizeof(EBR),1,arch);

                    /**   printf("EBRnueva: \n");
                       printf("Ebnueva next   %d\n",nuevoEBR.part_next);
                       printf("Ebnueva size   %d\n",nuevoEBR.part_size);
                       printf("Ebnueva staart %d\n",nuevoEBR.part_start);
                       printf("Ebnueva status %c\n",nuevoEBR.part_status);**/

                }



                printf("Particion %s Logica creada exitosamente \n",nombre);
                fclose(arch);
                return;

            }
            else
            {

                printf("No se puede crear una logica sin extendidas primero\n");
                fclose(arch);
                return;

            }


        }
        else                                                 ///si ya hay 4  pues mostramos un mensaje de error
        {

            printf("Lo sentimos ya ha llegado a 4 particiones entre extendidas y primarias \n");
            fclose(arch);
            return;

        }


    }
    else
    {
        printf("Error en Lectura del MBR  ");
    }
    fclose(arch);



}



void mount(char *ruta,char *nombre)
{


    FILE *arch = fopen(ruta,"rb");


    if (arch!=NULL)
    {


        MBRdisco lectura;
        EBR EBRleida;
        int pasar = 0;

        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);

        if(lectura.mbr_partition_1.part_start != -1 && lectura.mbr_partition_1.particion_status != '0')         ///si la particion esta activa buscamos los nombres
        {

            if(!strcmp(nombre,lectura.mbr_partition_1.part_name))           ///si es esta
            {

                //   printf("Hallamos la particion a montar\n");
                montarDisco(ruta);
                char id[5];
                id[0] = 'v';
                id[1] = 'd';
                id[2] = letra(ruta)+97;
                id[3] = quanti(ruta)+1;
                id[4] = '\0';

                montar(id,lectura.mbr_partition_1.part_start,nombre,lectura.mbr_partition_1.part_size,lectura.mbr_partition_1.part_type,ruta);


                return;
            }

            if(lectura.mbr_partition_1.part_type == 'e')                    ///sino entonces miramos si es extendida
            {
                fseek(arch,lectura.mbr_partition_1.part_start,SEEK_SET);    ///leemos su ebr
                fread(&EBRleida,sizeof(EBR),1,arch);

                while(EBRleida.part_next != -1)                             ///recorremos todas las posibles ebrs
                {

                    if(!strcmp(nombre,EBRleida.part_name))   ///si es esta logica la jalamos
                    {

//                        printf("Hallamos la particion a montar logica\n");
                        montarDisco(ruta);
                        char id[5];
                        id[0] = 'v';
                        id[1] = 'd';
                        id[2] = letra(ruta)+97;
                        id[3] = quanti(ruta)+1;
                        id[4] = '\0';
                        montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);


                        return;

                    }
                    else                                                    ///sino pasamos a la siguiente
                    {
                        //printf("%s %d y %s %d\n",nombre,strlen(nombre),EBRleida.part_name,strlen(EBRleida.part_name));
                        fseek(arch,EBRleida.part_next,SEEK_SET);            ///leemos el ebr siguiente
                        fread(&EBRleida,sizeof(EBR),1,arch);

                    }

                }



                if(!strcmp(nombre,EBRleida.part_name) && EBRleida.part_next == -1)   ///si es esta logica la jalamos
                {

                    ///printf("Hallamos la particion a montar logica\n");
                    montarDisco(ruta);
                    char id[5];
                    id[0] = 'v';
                    id[1] = 'd';
                    id[2] = letra(ruta)+97;
                    id[3] = quanti(ruta)+1;
                    id[4] = '\0';
                    montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);


                    return;

                }




            }
            pasar++;

        }

        if(lectura.mbr_partition_2.part_start != -1 && lectura.mbr_partition_2.particion_status != '0')         ///si la particion esta activa buscamos los nombres
        {

            if(!strcmp(nombre,lectura.mbr_partition_2.part_name))           ///si es esta
            {
                montarDisco(ruta);
                // printf("Hallamos la particion a montar\n");
                char id[5];
                id[0] = 'v';
                id[1] = 'd';
                id[2] = letra(ruta)+97;
                id[3] = quanti(ruta)+1;
                id[4] = '\0';
                montar(id,lectura.mbr_partition_2.part_start,nombre,lectura.mbr_partition_2.part_size,lectura.mbr_partition_2.part_type,ruta);

                return;
            }

            if(lectura.mbr_partition_2.part_type == 'e')                    ///sino entonces miramos si es extendida
            {
                fseek(arch,lectura.mbr_partition_2.part_start,SEEK_SET);    ///leemos su ebr
                fread(&EBRleida,sizeof(EBR),1,arch);

                while(EBRleida.part_next != -1)                             ///recorremos todas las posibles ebrs
                {

                    if(!strcmp(nombre,EBRleida.part_name))   ///si es esta logica la jalamos
                    {

                        ///printf("Hallamos la particion a montar logica\n");
                        montarDisco(ruta);
                        char id[5];
                        id[0] = 'v';
                        id[1] = 'd';
                        id[2] = letra(ruta)+97;
                        id[3] = quanti(ruta)+1;
                        id[4] = '\0';
                        montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);
                        return;

                    }
                    else                                                    ///sino pasamos a la siguiente
                    {

                        fseek(arch,EBRleida.part_next,SEEK_SET);            ///leemos el ebr siguiente
                        fread(&EBRleida,sizeof(EBR),1,arch);

                    }

                }

                if(!strcmp(nombre,EBRleida.part_name) && EBRleida.part_next == -1)   ///si es esta logica la jalamos
                {

                    ///printf("Hallamos la particion a montar logica\n");
                    montarDisco(ruta);
                    char id[5];
                    id[0] = 'v';
                    id[1] = 'd';
                    id[2] = letra(ruta)+97;
                    id[3] = quanti(ruta)+1;
                    id[4] = '\0';
                    montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);


                    return;

                }

            }
            pasar++;

        }

        if(lectura.mbr_partition_3.part_start != -1 && lectura.mbr_partition_3.particion_status != '0')         ///si la particion esta activa buscamos los nombres
        {

            if(!strcmp(nombre,lectura.mbr_partition_3.part_name))           ///si es esta
            {

                montarDisco(ruta);
                ///printf("Hallamos la particion a montar2\n");
                char id[5];
                id[0] = 'v';
                id[1] = 'd';
                id[2] = letra(ruta)+97;
                id[3] = quanti(ruta)+1;
                id[4] = '\0';
                montar(id,lectura.mbr_partition_3.part_start,nombre,lectura.mbr_partition_3.part_size,lectura.mbr_partition_3.part_type,ruta);
                return;

            }

            if(lectura.mbr_partition_3.part_type == 'e')                    ///sino entonces miramos si es extendida
            {
                fseek(arch,lectura.mbr_partition_3.part_start,SEEK_SET);    ///leemos su ebr
                fread(&EBRleida,sizeof(EBR),1,arch);

                while(EBRleida.part_next != -1)                             ///recorremos todas las posibles ebrs
                {

                    if(!strcmp(nombre,EBRleida.part_name))   ///si es esta logica la jalamos
                    {

                        ///printf("Hallamos la particion a montar logica\n");
                        montarDisco(ruta);
                        char id[5];
                        id[0] = 'v';
                        id[1] = 'd';
                        id[2] = letra(ruta)+97;
                        id[3] = quanti(ruta)+1;
                        id[4] = '\0';
                        montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);
                        return;


                    }
                    else                                                    ///sino pasamos a la siguiente
                    {

                        fseek(arch,EBRleida.part_next,SEEK_SET);            ///leemos el ebr siguiente
                        fread(&EBRleida,sizeof(EBR),1,arch);

                    }

                }


                if(!strcmp(nombre,EBRleida.part_name) && EBRleida.part_next == -1)   ///si es esta logica la jalamos
                {

                    ///printf("Hallamos la particion a montar logica\n");
                    montarDisco(ruta);
                    char id[5];
                    id[0] = 'v';
                    id[1] = 'd';
                    id[2] = letra(ruta)+97;
                    id[3] = quanti(ruta)+1;
                    id[4] = '\0';
                    montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);
                    return;

                }


            }
            pasar++;
        }

        if(lectura.mbr_partition_4.part_start != -1 && lectura.mbr_partition_4.particion_status != '0')         ///si la particion esta activa buscamos los nombres
        {

            if(!strcmp(nombre,lectura.mbr_partition_4.part_name))           ///si es esta
            {

                montarDisco(ruta);
                ///printf("Hallamos la particion a montar2\n");
                char id[5];
                id[0] = 'v';
                id[1] = 'd';
                id[2] = letra(ruta)+97;
                id[3] = quanti(ruta)+1;
                id[4] = '\0';
                montar(id,lectura.mbr_partition_4.part_start,nombre,lectura.mbr_partition_4.part_size,lectura.mbr_partition_4.part_type,ruta);
                return;
            }

            if(lectura.mbr_partition_4.part_type == 'e')                    ///sino entonces miramos si es extendida
            {
                fseek(arch,lectura.mbr_partition_4.part_start,SEEK_SET);    ///leemos su ebr
                fread(&EBRleida,sizeof(EBR),1,arch);

                while(EBRleida.part_next != -1)                             ///recorremos todas las posibles ebrs
                {

                    if(!strcmp(nombre,EBRleida.part_name))   ///si es esta logica la jalamos
                    {

                        ///printf("Hallamos la particion a montar logica\n");
                        montarDisco(ruta);
                        char id[5];
                        id[0] = 'v';
                        id[1] = 'd';
                        id[2] = letra(ruta)+97;
                        id[3] = quanti(ruta)+1;
                        id[4] = '\0';
                        montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);
                        return;

                    }
                    else                                                    ///sino pasamos a la siguiente
                    {

                        fseek(arch,EBRleida.part_next,SEEK_SET);            ///leemos el ebr siguiente
                        fread(&EBRleida,sizeof(EBR),1,arch);

                    }

                }

                if(!strcmp(nombre,EBRleida.part_name) && EBRleida.part_next == -1)   ///si es esta logica la jalamos
                {

                    ///printf("Hallamos la particion a montar logica\n");
                    montarDisco(ruta);
                    char id[5];
                    id[0] = 'v';
                    id[1] = 'd';
                    id[2] = letra(ruta)+97;
                    id[3] = quanti(ruta)+1;
                    id[4] = '\0';
                    montar(id,EBRleida.part_start,EBRleida.part_name,EBRleida.part_size,'l',ruta);


                    return;

                }

            }
            pasar++;
        }

        printf("La particion que desea montar no existe \n")        ;
        fclose(arch);
        return;

    }
    else
    {
        printf("Este disco no existe \n  ");
        return;

    }
    fclose(arch);



}



int letra(char* ruta)///nos da la letra correspondiente al id de la particion montada
{

    int f=0;
    int y=0;
    int t = 0;
    for(f; f<cantidadDiscosMontados; f++)
    {

        if(!strcmp(DiscosMontados[f].pathDisco,ruta))
        {
            return f;
        }

    }

    return t;

}


int quanti(char *ruta) ///nos da el numero para el id de la particion montada
{

    int f=0;
    int y=0;
    for(f; f<cantidadDiscosMontados; f++)
    {

        if(!strcmp(DiscosMontados[f].pathDisco,ruta))
        {

            y = DiscosMontados[f].vecesMontado;
            break;

        }

    }


    if(y==1)
    {
        return 49;
    }
    else if(y==2)
    {
        return 50;
    }
    else if(y==3)
    {
        return 51;
    }
    else if(y==4)
    {
        return 52;
    }
    else if(y==5)
    {
        return 53;
    }
    else if(y==6)
    {
        return 54;
    }
    else if(y==7)
    {
        return 55;
    }
    else if(y==8)
    {
        return 56;
    }
    else if(y==9)
    {
        return 57;
    }

    return 48;

}



void montar(char *id, int inicio, char*nombre,int tamanio, char type, char* ruta)///lo mete al vector de particiones montadas
{


    ParticionesMontadas[cantidadParticionesMontadas].byteInicio = inicio;
    ParticionesMontadas[cantidadParticionesMontadas].montado = '1';
    strcpy(ParticionesMontadas[cantidadParticionesMontadas].id,id);
    strcpy(ParticionesMontadas[cantidadParticionesMontadas].nombreParticion,nombre);
    strcpy(ParticionesMontadas[cantidadParticionesMontadas].pathDisco,ruta);
    ParticionesMontadas[cantidadParticionesMontadas].tamanio = tamanio;
    ParticionesMontadas[cantidadParticionesMontadas].tipo = type;
    cantidadParticionesMontadas++;
    printf("Montada con el id:       %s\n",id);

}



void montarDisco(char* ruta)///lo mete al vector de discos montados
{

    int x=0;
    int hallado=0;///0 no esta, 1 si esta



    for(x; x<cantidadDiscosMontados; x++)
    {

        if(!strcmp(ruta,DiscosMontados[x].pathDisco))
        {

            hallado = 1;
            break;

        }
    }

    if(hallado==1)
    {

        DiscosMontados[x].vecesMontado++;
        //   printf("%d , %d \n",DiscosMontados[x].vecesMontado,x);

    }
    else
    {

        strcpy(DiscosMontados[x].pathDisco,ruta);
        DiscosMontados[x].vecesMontado = 0;
        cantidadDiscosMontados++;
    }


}


void unmount(char* idParticion)
{

    int h=0;
    ///printf("%d\n",cantidadParticionesMontadas);
    if(cantidadParticionesMontadas != 0)
    {
        for(h; h<cantidadParticionesMontadas; h++)
        {

            if(!strcmp(ParticionesMontadas[h].id,idParticion))
            {

                int h2=h;
                particionMontada f = ParticionesMontadas[cantidadParticionesMontadas-1];
                for(h2; h2<cantidadParticionesMontadas; h2++)
                {

                    if(!strcmp(ParticionesMontadas[h].id,idParticion))  ///ver si no da clavo en grandes cantidades de particiones montadas
                    {
                        ParticionesMontadas[h2]=ParticionesMontadas[h2+1];
                    }

                    if(h2 == cantidadParticionesMontadas -2){

                        ParticionesMontadas[h2] = f;
                    }

                }

                cantidadParticionesMontadas--;
                return;

            }
            else if(h==cantidadParticionesMontadas-1)
            {

                printf("Error la particion con id %s no esta montada... \n",idParticion);
                return;

            }


        }
    }
    else
    {

        printf("Para desmontar una particion , deben existir particiones montadas primero \n");
    }

}


void imprimirParticionesMontadas()
{

    int h=0;
    printf("No.  Id    Nombre      Ruta                                    Tipo\n") ;
    for(h; h<cantidadParticionesMontadas; h++)
    {
        printf("%d    %s  %s  %s                 %c\n",h+1,ParticionesMontadas[h].id,ParticionesMontadas[h].nombreParticion,ParticionesMontadas[h].pathDisco,ParticionesMontadas[h].tipo) ;


    }

}



void ReporteDeParticiones(char *ruta,char *dir)
{
    printf("Reporte de Disco para %s , generado exitosamente\n",ruta);

    int totalParticiones =          0;///primarias y extendidas
    int particionesLogicas =        0;
    int particionesExtendidas =     0;
    int particionesPrimarias =      0;

    ///estas las vamos a usar para calcular el byte de inicio de la particion nueva
    int inicio1 = -1;
    int tamanio1= -1;
    int inicio2= -1;
    int tamanio2= -1;
    int inicio3= -1;
    int tamanio3= -1;
    int inicio4= -1;
    int tamanio4= -1;
    int fin1= -1;
    int fin2= -1;
    int fin3= -1;
    int fin4= -1;
    char tipo1;
    char tipo2;
    char tipo3;
    char tipo4;
    int tamanio;
    int multi;
    int byteInicio;
    char j[1000] = "graph {\n splines=line;\n subgraph cluster_0 { label= \"";
    strcat(j,ruta);
    strcat(j,"\";\n");
    int Pos = -1;

    int inicioPart1=0;
    int finPart1=0;
    char tipo11;

    /*esta las usamos para el reporte con 2 particiones*/
    int inicioPart21=0;
    int inicioPart22=0;
    int finPart21=0;
    int finPart22=0;
    char tipo21;
    char tipo22;
    /*esta las manejamos para el reporte con 3 particiones*/
    int inicioPart31=0;
    int inicioPart32=0;
    int inicioPart33=0;
    int finPart33=0;
    int finPart31=0;
    int finPart32=0;
    char tipo31;
    char tipo32;
    char tipo33;
    char NombreParticion1[50];
    char NombreParticion2[50];
    char NombreParticion3[50];
    char NombreParticion4[50];
    /*esta las manejamos para el reporte con 4 partiociones*/
    /*esta las manejamos para el reporte con 3 particiones*/
    int inicioPart41=0;
    int inicioPart42=0;
    int inicioPart43=0;
    int inicioPart44=0;

    char tipo41;
    char tipo42;
    char tipo43;
    char tipo44;
    int finPart41=0;
    int finPart42=0;
    int finPart43=0;
    int finPart44=0;






    FILE *arch = fopen(ruta,"rb+");

    if (arch!=NULL)
    {


        MBRdisco lectura;
        EBR EBRleida;
        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);



        /** con este codigo vamos recorriendo las particiones del mbr y vamos sacando los totales numericos de particiones*/

        if(lectura.mbr_partition_1.particion_status == '1')
        {
            totalParticiones++;
            tamanio1=lectura.mbr_partition_1.part_size;
            inicio1=lectura.mbr_partition_1.part_start;
            fin1=inicio1+tamanio1;
            tipo1 = lectura.mbr_partition_1.part_type;
            if(lectura.mbr_partition_1.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_1.part_type=='e')
            {
                particionesExtendidas++;
            }
        }

        if(lectura.mbr_partition_2.particion_status == '1')
        {
            totalParticiones++;
            tamanio2=lectura.mbr_partition_2.part_size;
            inicio2=lectura.mbr_partition_2.part_start;
            fin2=inicio2+tamanio2;
            tipo2 = lectura.mbr_partition_2.part_type;
            if(lectura.mbr_partition_2.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_2.part_type=='e')
            {
                particionesExtendidas++;
            }
        }

        if(lectura.mbr_partition_3.particion_status == '1')
        {
            totalParticiones++;
            tamanio3=lectura.mbr_partition_3.part_size;
            inicio3=lectura.mbr_partition_3.part_start;
            fin3=inicio3+tamanio3;
            tipo3 = lectura.mbr_partition_3.part_type;
            if(lectura.mbr_partition_3.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_3.part_type=='e')
            {
                particionesExtendidas++;
            }
        }

        if(lectura.mbr_partition_4.particion_status == '1')
        {
            totalParticiones++;
            tamanio4=lectura.mbr_partition_4.part_size;
            inicio4=lectura.mbr_partition_4.part_start;
            fin4=inicio4+tamanio4;
            tipo4 = lectura.mbr_partition_4.part_type;
            if(lectura.mbr_partition_4.part_type=='p')
            {
                particionesPrimarias++;
            }
            else if(lectura.mbr_partition_4.part_type=='e')
            {
                particionesExtendidas++;
            }
        }

        int posExt = 0;

        if(totalParticiones==0)                                                 ///sino hay particiones entonces dibujamos un disco con mbr y espacio limpio
        {

            strcat(j,"Libre[shape=square];\n");
            strcat(j,"MBR[shape=square];\n}\n}");
            ///printf("%s",j);


        }
        else if(totalParticiones==1)                                            ///si  hay 1 particion: entonces necesitamos cual es la particion que esta creada
        {



            //printf("Graficamos 1 particiones \n");

            if(tamanio1 != -1)                                                  ///despues, vamos a calcular donde hay espacio para nuestra particion, si antes de la ya creada o despues
            {

                inicioPart1=inicio1;
                finPart1=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                tipo11 = tipo1;


                if(tipo11 == 'e')
                {

                    posExt= 1;

                }

            }
            else if(tamanio2 != -1)
            {

                inicioPart1=inicio2;
                finPart1=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                tipo11 = tipo2;


                if(tipo11 == 'e')
                {

                    posExt= 2;

                }

            }
            else if(tamanio3 != -1)
            {

                inicioPart1=inicio3;
                finPart1=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                tipo11 = tipo3;

                if(tipo11 == 'e')
                {

                    posExt= 3;

                }

            }
            else if(tamanio4 != -1)
            {
                inicioPart1=inicio4;
                finPart1=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                tipo11 = tipo4;

                if(tipo11 == 'e')
                {

                    posExt= 4;

                }

            }

            if((inicioPart1-sizeof(MBRdisco)) > 0 && (lectura.mbr_tamanio - finPart1) > 0)                              ///si entre el mbr y el inicio de la particion hay espacio mayor a cero
            {
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\n");
                strcat(j,"Libre2[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\n");
                strcat(j,"Libre[color=white];\n}");


            }
            else if((inicioPart1-sizeof(MBRdisco)) == 0 && (lectura.mbr_tamanio - finPart1) > 0)    ///sino entonces se verifica que el tamanio del disco - el fin de la primera sea mayor o igual par apoder imprimr despues
            {
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\n");
                strcat(j,"Libre[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart1-sizeof(MBRdisco)) > 0 && (lectura.mbr_tamanio - finPart1) == 0 )
            {

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\n");
                strcat(j,"Libre[color=white];\n}");

            }



        }
        else if(totalParticiones==2)                                            ///si hay 2 buscamos espacios antes de la primera , entre ambas, y al final de la 2da
        {
            // printf("Graficamos 2 particiones %s\n",ruta);



            char NombreParticion1[50];
            char NombreParticion2[50];

            if(tamanio1 != -1 && tamanio2 != -1)
            {


                if(inicio1 < inicio2)
                {

                    inicioPart21 = inicio1;
                    inicioPart22 = inicio2;
                    finPart21 = fin1;
                    finPart22 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    tipo21 = tipo1;
                    tipo22 = tipo2;

                }
                else
                {

                    inicioPart21 = inicio2;
                    inicioPart22 = inicio1;
                    finPart21 = fin2;
                    finPart22 = fin1;
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    tipo21 = tipo2;
                    tipo22 = tipo1;


                }

            }
            else if(tamanio1 != -1 && tamanio3 != -1)
            {

                if(inicio1 < inicio3)
                {

                    inicioPart21 = inicio1;
                    inicioPart22 = inicio3;
                    finPart21 = fin1;
                    finPart22 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    tipo21 = tipo1;
                    tipo22 = tipo3;


                }
                else
                {

                    inicioPart21 = inicio3;
                    inicioPart22 = inicio1;
                    finPart21 = fin3;
                    finPart22 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    tipo21 = tipo3;
                    tipo22 = tipo1;

                }

            }
            else if(tamanio1 != -1 && tamanio4 != -1)
            {

                if(inicio1 < inicio4)
                {

                    inicioPart21 = inicio1;
                    inicioPart22 = inicio4;
                    finPart21 = fin1;
                    finPart22 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    tipo21 = tipo1;
                    tipo22 = tipo4;

                }
                else
                {

                    inicioPart21 = inicio4;
                    inicioPart22 = inicio1;
                    finPart21 = fin4;
                    finPart22 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    tipo21 = tipo4;
                    tipo22 = tipo1;

                }


            }
            else if(tamanio2 != -1 && tamanio3 != -1)
            {

                if(inicio2 < inicio3)
                {

                    inicioPart21 = inicio2;
                    inicioPart22 = inicio3;
                    finPart21 = fin2;
                    finPart22 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    tipo21 = tipo2;
                    tipo22 = tipo3;

                }
                else
                {

                    inicioPart21 = inicio3;
                    inicioPart22 = inicio2;
                    finPart21 = fin3;
                    finPart22 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    tipo21 = tipo3;
                    tipo22 = tipo2;
                }



            }
            else if(tamanio2 != -1 && tamanio4 != -1)
            {

                if(inicio2 < inicio4)
                {

                    inicioPart21 = inicio2;
                    inicioPart22 = inicio4;
                    finPart21 = fin2;
                    finPart22 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    tipo21 = tipo2;
                    tipo22 = tipo4;

                }
                else
                {

                    inicioPart21 = inicio4;
                    inicioPart22 = inicio2;
                    finPart21 = fin4;
                    finPart22 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    tipo21 = tipo4;
                    tipo22 = tipo2;

                }

            }
            else if(tamanio3 != -1 && tamanio4 != -1)
            {

                if(inicio3 < inicio4)
                {

                    inicioPart21 = inicio3;
                    inicioPart22 = inicio4;
                    finPart21 = fin3;
                    finPart22 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    tipo21 = tipo3;
                    tipo22 = tipo4;

                }
                else
                {

                    inicioPart21 = inicio4;
                    inicioPart22 = inicio3;
                    finPart21 = fin4;
                    finPart22 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    tipo21 = tipo4;
                    tipo22 = tipo3;

                }

            }


            if((inicioPart21-sizeof(MBRdisco)) == 0 && (inicioPart22 - finPart21) == 0 &&  (lectura.mbr_tamanio-finPart22) == 0 )                       ///LLENO
            {

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart21-sizeof(MBRdisco)) == 0 && (inicioPart22 - finPart21) == 0 &&  (lectura.mbr_tamanio-finPart22) > 0 )                 ///espacio al final
            {
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart21-sizeof(MBRdisco)) == 0 && (inicioPart22 - finPart21)> 0 &&  (lectura.mbr_tamanio-finPart22) == 0)                ///espacio penultimo
            {


                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart21-sizeof(MBRdisco)) > 0 && (inicioPart22 - finPart21) == 0 &&  (lectura.mbr_tamanio-finPart22) == 0)                ///espacio antepenultimo
            {

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart21-sizeof(MBRdisco)) > 0 && (inicioPart22 - finPart21) > 0 &&  (lectura.mbr_tamanio-finPart22) == 0)                ///espacio entre mbr y disco1, entre 1y2 , lleno al final
            {

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");



            }
            else if((inicioPart21-sizeof(MBRdisco)) > 0 && (inicioPart22 - finPart21) == 0 &&  (lectura.mbr_tamanio-finPart22) > 0)                ///espacio entre mbr y disco1, espacio al final
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart21-sizeof(MBRdisco)) == 0 && (inicioPart22 - finPart21) > 0 &&  (lectura.mbr_tamanio-finPart22) > 0)                ///espacio entre 1 y 2 , y al final
            {
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart21-sizeof(MBRdisco)) > 0 && (inicioPart22 - finPart21) > 0 &&  (lectura.mbr_tamanio-finPart22) > 0)                ///espacio entre mbr y disco1 , disco1 y disco2 , disco2 y fin
            {
                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
            }



            if(tipo21 == 'e')
            {

                posExt= 1;

            }
            else if(tipo22 == 'e')
            {

                posExt= 2;

            }





        }
        else if(totalParticiones==3)                                            ///si hay 3 particiones vemos el orden y buscamos espacios antes , enmedio y al final de ellas
        {
            //printf("Graficamos 3 particiones %s \n",ruta);
            if(tamanio1 == -1)                                                          ///las particiones ocupadas son 2,3,4
            {

                if(inicio2<inicio3 && inicio3<inicio4)                                             ///abc
                {
                    inicioPart31 = inicio2;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio4;
                    finPart31 = fin2;
                    finPart32 = fin3;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo3;
                    tipo33 = tipo4;

                }
                else if(inicio2<inicio4 && inicio4<inicio3)                                        ///acb
                {
                    inicioPart31 = inicio2;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio3;
                    finPart31 = fin2;
                    finPart32 = fin4;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo4;
                    tipo33 = tipo3;

                }
                else if(inicio3<inicio2 && inicio2<inicio4)                                        ///bac
                {
                    inicioPart31 = inicio3;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio4;
                    finPart31 = fin3;
                    finPart32 = fin2;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo2;
                    tipo33 = tipo4;


                }
                else if(inicio3<inicio4 && inicio4<inicio2)                                        ///bca
                {
                    inicioPart31 = inicio3;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio2;
                    finPart31 = fin3;
                    finPart32 = fin4;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo4;
                    tipo33 = tipo2;


                }
                else if(inicio4<inicio2 && inicio2<inicio3)                                        ///cab
                {
                    inicioPart31 = inicio4;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio3;
                    finPart31 = fin4;
                    finPart32 = fin2;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo2;
                    tipo33 = tipo3;

                }
                else if(inicio4<inicio3 && inicio3<inicio2)                                        ///cba
                {
                    inicioPart31 = inicio4;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio2;
                    finPart31 = fin4;
                    finPart32 = fin3;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo3;
                    tipo33 = tipo2;


                }



            }
            else if(tamanio2 == -1)                                                     ///las particiones ocupadas son 1,3,4
            {

                if(inicio1<inicio3 && inicio3<inicio4)                                             ///abc
                {
                    inicioPart31 = inicio1;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio4;
                    finPart31 = fin1;
                    finPart32 = fin3;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo3;
                    tipo33 = tipo4;

                }
                else if(inicio1<inicio4 && inicio4<inicio3)                                        ///acb
                {

                    inicioPart31 = inicio1;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio3;
                    finPart31 = fin1;
                    finPart32 = fin4;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo4;
                    tipo33 = tipo3;

                }
                else if(inicio3<inicio1 && inicio1<inicio4)                                        ///bac
                {

                    inicioPart31 = inicio3;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio4;
                    finPart31 = fin3;
                    finPart32 = fin1;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo1;
                    tipo33 = tipo4;


                }
                else if(inicio3<inicio4 && inicio4<inicio1)                                        ///bca
                {
                    inicioPart31 = inicio3;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio1;
                    finPart31 = fin3;
                    finPart32 = fin4;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo4;
                    tipo33 = tipo1;

                }
                else if(inicio4<inicio1 && inicio1<inicio3)                                        ///cab
                {
                    inicioPart31 = inicio4;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio3;
                    finPart31 = fin4;
                    finPart32 = fin1;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo1;
                    tipo33 = tipo3;


                }
                else if(inicio4<inicio3 && inicio3<inicio1)                                        ///cba
                {
                    inicioPart31 = inicio4;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio1;
                    finPart31 = fin4;
                    finPart32 = fin3;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo3;
                    tipo33 = tipo1;


                }



            }
            else if(tamanio3 == -1)                                                     ///las particiones ocupadas son 1,2,4
            {

                if(inicio1<inicio2 && inicio2<inicio4)                                             ///abc
                {

                    inicioPart31 = inicio1;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio4;
                    finPart31 = fin1;
                    finPart32 = fin2;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo2;
                    tipo33 = tipo4;


                }
                else if(inicio1<inicio4 && inicio4<inicio2)                                        ///acb
                {

                    inicioPart31 = inicio1;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio2;
                    finPart31 = fin1;
                    finPart32 = fin4;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo4;
                    tipo33 = tipo2;

                }
                else if(inicio2<inicio1 && inicio1<inicio4)                                        ///bac
                {

                    inicioPart31 = inicio2;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio4;
                    finPart31 = fin2;
                    finPart32 = fin1;
                    finPart33 = fin4;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo1;
                    tipo33 = tipo4;

                }
                else if(inicio2<inicio4 && inicio4<inicio1)                                        ///bca
                {

                    inicioPart31 = inicio2;
                    inicioPart32 = inicio4;
                    inicioPart33 = inicio1;
                    finPart31 = fin2;
                    finPart32 = fin4;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo4;
                    tipo33 = tipo1;


                }
                else if(inicio4<inicio1 && inicio1<inicio2)                                        ///cab
                {

                    inicioPart31 = inicio4;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio2;
                    finPart31 = fin4;
                    finPart32 = fin1;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo1;
                    tipo33 = tipo2;


                }
                else if(inicio4<inicio2 && inicio2<inicio1)                                        ///cba
                {

                    inicioPart31 = inicio4;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio1;
                    finPart31 = fin4;
                    finPart32 = fin2;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo4;
                    tipo32 = tipo2;
                    tipo33 = tipo1;

                }

            }
            else if(tamanio4 == -1)                                                     ///las particiones ocupadas son 1,2,3
            {


                if(inicio1<inicio2<inicio3)                                             ///abc
                {
                    //printf("1 2 3 \n");
                    inicioPart31 = inicio1;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio3;
                    finPart31 = fin1;
                    finPart32 = fin2;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo2;
                    tipo33 = tipo3;

                }
                else if(inicio1<inicio3 && inicio3<inicio2)                                        ///acb
                {

                    inicioPart31 = inicio1;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio2;
                    finPart31 = fin1;
                    finPart32 = fin3;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo1;
                    tipo32 = tipo3;
                    tipo33 = tipo2;


                }
                else if(inicio2<inicio1 && inicio1<inicio3)                                        ///bac
                {

                    inicioPart31 = inicio2;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio3;
                    finPart31 = fin2;
                    finPart32 = fin1;
                    finPart33 = fin3;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo1;
                    tipo33 = tipo3;

                }
                else if(inicio2<inicio3 && inicio3<inicio1)                                        ///bca
                {

                    inicioPart31 = inicio2;
                    inicioPart32 = inicio3;
                    inicioPart33 = inicio1;
                    finPart31 = fin2;
                    finPart32 = fin3;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo2;
                    tipo32 = tipo3;
                    tipo33 = tipo1;

                }
                else if(inicio3<inicio1 && inicio1<inicio2)                                        ///cab
                {

                    inicioPart31 = inicio3;
                    inicioPart32 = inicio1;
                    inicioPart33 = inicio2;
                    finPart31 = fin3;
                    finPart32 = fin1;
                    finPart33 = fin2;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo1;
                    tipo33 = tipo2;

                }
                else if(inicio3<inicio2 && inicio2<inicio1)                                        ///cba
                {

                    inicioPart31 = inicio3;
                    inicioPart32 = inicio2;
                    inicioPart33 = inicio1;
                    finPart31 = fin3;
                    finPart32 = fin2;
                    finPart33 = fin1;
                    strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                    strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                    strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                    tipo31 = tipo3;
                    tipo32 = tipo2;
                    tipo33 = tipo1;

                }

            }



            if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) == 0 && (lectura.mbr_tamanio - finPart33) ==0 ) ///lleno
            {
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32)==0 && (lectura.mbr_tamanio - finPart33) ==0) ///espacio depsues del mbr
            {
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) ==0) ///despues de la 1
            {

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) >0&& (lectura.mbr_tamanio - finPart33) ==0) ///despues de la 2
            {
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) >0) ///despues de la 3 o al final
            {
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) >0) ///1 y ultima
            {
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) ==0) ///1 y 2
            {

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre[color=white];\n}");
            }
            else if((inicioPart31-sizeof(MBRdisco))> 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) >0&& (lectura.mbr_tamanio - finPart33) ==0) ///1 y 3
            {

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) >0&& (lectura.mbr_tamanio - finPart33) ==0) ///2 y 3
            {

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) >0) ///2 y 4
            {
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart31-sizeof(MBRdisco)) == 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) >0 && (lectura.mbr_tamanio - finPart33) >0) ///3 y 4
            {

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) >0 && (lectura.mbr_tamanio - finPart33) ==0) ///1 2 3
            {
                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre[color=white];\n}");
            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) ==0&& (lectura.mbr_tamanio - finPart33) >0) ///124
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre[color=white];\n}");
            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)==0 &&(inicioPart33-finPart32) > 0 && (lectura.mbr_tamanio - finPart33) >0) ///134
            {
                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");
                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre[color=white];\n}");
            }
            else if((inicioPart31-sizeof(MBRdisco)) > 0 && (inicioPart32-finPart31)>0 &&(inicioPart33-finPart32) > 0 && (lectura.mbr_tamanio - finPart33) >0) ///1234
            {
                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre[color=white];\n}");
            }



            if(tipo31 == 'e')
            {

                posExt= 1;

            }
            else if(tipo32 == 'e')
            {

                posExt= 2;

            }
            else if(tipo33 == 'e')
            {

                posExt= 3;

            }

        }
        else if(totalParticiones==4)
        {

            //printf("Graficamos 4 particiones %s \n",ruta);

            if(inicio1<inicio2 && inicio2<inicio3 && inicio3<inicio4) ///abcd
            {


                inicioPart41=inicio1;
                inicioPart42=inicio2;
                inicioPart43=inicio3;
                inicioPart44=inicio4;
                finPart41=fin1;
                finPart42=fin2;
                finPart43=fin3;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo1;
                tipo42 = tipo2;
                tipo43 = tipo3;
                tipo44 = tipo4;


            }
            else if(inicio1<inicio2 && inicio2<inicio4 && inicio4<inicio3)  ///abdc
            {

                inicioPart41=inicio1;
                inicioPart42=inicio2;
                inicioPart43=inicio4;
                inicioPart44=inicio3;
                finPart41=fin1;
                finPart42=fin2;
                finPart43=fin4;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo1;
                tipo42 = tipo2;
                tipo43 = tipo4;
                tipo44 = tipo3;


            }
            else if(inicio1<inicio3 && inicio3<inicio2 && inicio2<inicio4)  ///acbd
            {


                inicioPart41=inicio1;
                inicioPart42=inicio3;
                inicioPart43=inicio2;
                inicioPart44=inicio4;
                finPart41=fin1;
                finPart42=fin3;
                finPart43=fin2;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo1;
                tipo42 = tipo3;
                tipo43 = tipo2;
                tipo44 = tipo4;


            }
            else if(inicio1<inicio3 && inicio3<inicio4 && inicio4<inicio2)  ///acdb
            {

                inicioPart41=inicio1;
                inicioPart42=inicio3;
                inicioPart43=inicio4;
                inicioPart44=inicio2;
                finPart41=fin1;
                finPart42=fin3;
                finPart43=fin4;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo1;
                tipo42 = tipo3;
                tipo43 = tipo4;
                tipo44 = tipo2;



            }
            else if(inicio1<inicio4 && inicio4<inicio2 && inicio2<inicio3)  ///adbc
            {

                inicioPart41=inicio1;
                inicioPart42=inicio4;
                inicioPart43=inicio2;
                inicioPart44=inicio3;
                finPart41=fin1;
                finPart42=fin4;
                finPart43=fin2;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo1;
                tipo42 = tipo4;
                tipo43 = tipo2;
                tipo44 = tipo3;


            }
            else if(inicio1<inicio4 && inicio4<inicio3 && inicio3<inicio2)  ///adcb
            {

                inicioPart41=inicio1;
                inicioPart42=inicio4;
                inicioPart43=inicio3;
                inicioPart44=inicio2;
                finPart41=fin1;
                finPart42=fin4;
                finPart43=fin3;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo1;
                tipo42 = tipo4;
                tipo43 = tipo3;
                tipo44 = tipo2;



            }
            else if(inicio2<inicio1 && inicio1<inicio3 && inicio3<inicio4)  ///bacd
            {


                inicioPart41=inicio2;
                inicioPart42=inicio1;
                inicioPart43=inicio3;
                inicioPart44=inicio4;
                finPart41=fin2;
                finPart42=fin1;
                finPart43=fin3;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo2;
                tipo42 = tipo1;
                tipo43 = tipo3;
                tipo44 = tipo4;


            }
            else if(inicio2<inicio1 && inicio1<inicio4 && inicio4<inicio3)  ///badc
            {

                inicioPart41=inicio2;
                inicioPart42=inicio1;
                inicioPart43=inicio4;
                inicioPart44=inicio3;
                finPart41=fin2;
                finPart42=fin1;
                finPart43=fin4;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo2;
                tipo42 = tipo1;
                tipo43 = tipo4;
                tipo44 = tipo3;



            }
            else if(inicio2<inicio3 && inicio3<inicio1 && inicio1<inicio4)  ///bcad
            {

                inicioPart41=inicio2;
                inicioPart42=inicio3;
                inicioPart43=inicio1;
                inicioPart44=inicio4;
                finPart41=fin2;
                finPart42=fin3;
                finPart43=fin1;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo2;
                tipo42 = tipo3;
                tipo43 = tipo1;
                tipo44 = tipo4;



            }
            else if(inicio2<inicio3 && inicio3<inicio4 && inicio4<inicio1)  ///bcda
            {

                inicioPart41=inicio2;
                inicioPart42=inicio3;
                inicioPart43=inicio4;
                inicioPart44=inicio1;
                finPart41=fin2;
                finPart42=fin3;
                finPart43=fin4;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo2;
                tipo42 = tipo3;
                tipo43 = tipo4;
                tipo44 = tipo1;



            }
            else if(inicio2<inicio4 && inicio4<inicio1 && inicio1<inicio3)  ///bdac
            {

                inicioPart41=inicio2;
                inicioPart42=inicio4;
                inicioPart43=inicio1;
                inicioPart44=inicio3;
                finPart41=fin2;
                finPart42=fin4;
                finPart43=fin1;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo2;
                tipo42 = tipo4;
                tipo43 = tipo1;
                tipo44 = tipo3;



            }
            else if(inicio2<inicio4 && inicio4<inicio3 && inicio3<inicio1)  ///bdca
            {

                inicioPart41=inicio2;
                inicioPart42=inicio4;
                inicioPart43=inicio3;
                inicioPart44=inicio1;
                finPart41=fin2;
                finPart42=fin4;
                finPart43=fin3;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo2;
                tipo42 = tipo4;
                tipo43 = tipo3;
                tipo44 = tipo1;


            }
            else if(inicio3<inicio1 && inicio1<inicio2 && inicio2<inicio4)  ///cabd
            {

                inicioPart41=inicio3;
                inicioPart42=inicio1;
                inicioPart43=inicio3;
                inicioPart44=inicio4;
                finPart41=fin3;
                finPart42=fin1;
                finPart43=fin2;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo3;
                tipo42 = tipo1;
                tipo43 = tipo2;
                tipo44 = tipo4;



            }
            else if(inicio3<inicio1 && inicio1<inicio4 && inicio4<inicio2)  ///cadb
            {


                inicioPart41=inicio3;
                inicioPart42=inicio1;
                inicioPart43=inicio4;
                inicioPart44=inicio2;
                finPart41=fin3;
                finPart42=fin1;
                finPart43=fin4;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo3;
                tipo42 = tipo1;
                tipo43 = tipo4;
                tipo44 = tipo2;


            }
            else if(inicio3<inicio2 && inicio2<inicio1 && inicio1<inicio4)  ///cbad
            {


                inicioPart41=inicio3;
                inicioPart42=inicio2;
                inicioPart43=inicio1;
                inicioPart44=inicio4;
                finPart41=fin3;
                finPart42=fin2;
                finPart43=fin1;
                finPart44=fin4;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_4.part_name);
                tipo41 = tipo3;
                tipo42 = tipo2;
                tipo43 = tipo1;
                tipo44 = tipo4;


            }
            else if(inicio3<inicio2 && inicio2<inicio4 && inicio4<inicio1)  ///cbda
            {


                inicioPart41=inicio3;
                inicioPart42=inicio2;
                inicioPart43=inicio4;
                inicioPart44=inicio1;
                finPart41=fin3;
                finPart42=fin2;
                finPart43=fin4;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo3;
                tipo42 = tipo2;
                tipo43 = tipo4;
                tipo44 = tipo1;



            }
            else if(inicio3<inicio4 && inicio4<inicio1 && inicio1<inicio2)  ///cdab
            {


                inicioPart41=inicio3;
                inicioPart42=inicio4;
                inicioPart43=inicio1;
                inicioPart44=inicio2;
                finPart41=fin3;
                finPart42=fin4;
                finPart43=fin1;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo3;
                tipo42 = tipo4;
                tipo43 = tipo1;
                tipo44 = tipo2;



            }
            else if(inicio3<inicio4 && inicio4<inicio2 && inicio2<inicio1)  ///cdbaxxxx
            {

                inicioPart41=inicio3;
                inicioPart42=inicio4;
                inicioPart43=inicio2;
                inicioPart44=inicio1;
                finPart41=fin3;
                finPart42=fin4;
                finPart43=fin2;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo3;
                tipo42 = tipo4;
                tipo43 = tipo2;
                tipo44 = tipo1;


            }
            else if(inicio4<inicio1 && inicio1<inicio2 && inicio2<inicio3)  ///dabc
            {

                inicioPart41=inicio4;
                inicioPart42=inicio1;
                inicioPart43=inicio2;
                inicioPart44=inicio3;
                finPart41=fin4;
                finPart42=fin1;
                finPart43=fin2;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo4;
                tipo42 = tipo1;
                tipo43 = tipo2;
                tipo44 = tipo3;


            }
            else if(inicio4<inicio1 && inicio1<inicio3 && inicio3<inicio2)  ///dacb
            {

                inicioPart41=inicio4;
                inicioPart42=inicio1;
                inicioPart43=inicio3;
                inicioPart44=inicio2;
                finPart41=fin4;
                finPart42=fin1;
                finPart43=fin3;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo4;
                tipo42 = tipo1;
                tipo43 = tipo3;
                tipo44 = tipo2;


            }
            else if(inicio4<inicio2 && inicio2<inicio1 && inicio1<inicio3)  ///dbac
            {

                inicioPart41=inicio4;
                inicioPart42=inicio2;
                inicioPart43=inicio1;
                inicioPart44=inicio3;
                finPart41=fin4;
                finPart42=fin2;
                finPart43=fin1;
                finPart44=fin3;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_3.part_name);
                tipo41 = tipo4;
                tipo42 = tipo2;
                tipo43 = tipo1;
                tipo44 = tipo3;


            }
            else if(inicio4<inicio2 && inicio2<inicio3 && inicio3<inicio1)  ///dbca
            {

                inicioPart41=inicio4;
                inicioPart42=inicio2;
                inicioPart43=inicio3;
                inicioPart44=inicio1;
                finPart41=fin4;
                finPart42=fin2;
                finPart43=fin3;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo4;
                tipo42 = tipo2;
                tipo43 = tipo3;
                tipo44 = tipo1;


            }
            else if(inicio4<inicio3 && inicio3<inicio1 && inicio1<inicio2)  ///dcab
            {

                inicioPart41=inicio4;
                inicioPart42=inicio3;
                inicioPart43=inicio1;
                inicioPart44=inicio2;
                finPart41=fin4;
                finPart42=fin3;
                finPart43=fin1;
                finPart44=fin2;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_1.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_2.part_name);
                tipo41 = tipo4;
                tipo42 = tipo3;
                tipo43 = tipo1;
                tipo44 = tipo2;


            }
            else if(inicio4<inicio3 && inicio3<inicio2 && inicio2<inicio1)  ///bacd
            {

                inicioPart41=inicio4;
                inicioPart42=inicio3;
                inicioPart43=inicio2;
                inicioPart44=inicio1;
                finPart41=fin4;
                finPart42=fin3;
                finPart43=fin2;
                finPart44=fin1;
                strcpy(NombreParticion1,lectura.mbr_partition_4.part_name);
                strcpy(NombreParticion2,lectura.mbr_partition_3.part_name);
                strcpy(NombreParticion3,lectura.mbr_partition_2.part_name);
                strcpy(NombreParticion4,lectura.mbr_partition_1.part_name);
                tipo41 = tipo4;
                tipo42 = tipo3;
                tipo43 = tipo2;
                tipo44 = tipo1;


            }



            if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0) ///lleno
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///5
            {


                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///4
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///3
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///2
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///1
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///12
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///13
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///14
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///15
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///23
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///24
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///25
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///34
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///35
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///45
            {

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///123
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///124
            {

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///125
            {


                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///134
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///135
            {



                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///145
            {


                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///245
            {


                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");


                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///345
            {


                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///235
            {


                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///234
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) == 0)  ///1234
            {


                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) == 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///1235
            {


                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) == 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///1245
            {


                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) == 0 && (inicioPart43- finPart42) >0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///1345
            {


                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) == 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///2345
            {

                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");


            }
            else if((inicioPart41-sizeof(MBRdisco)) > 0 && (inicioPart42- finPart41) > 0 && (inicioPart43- finPart42) > 0 && (inicioPart44- finPart43) > 0 && (lectura.mbr_tamanio - finPart44) > 0)  ///12345
            {


                strcat(j,"subgraph cluster_9{\nlabel=\"\";\nLibre5[color=white];\n}");

                strcat(j,"subgraph cluster_4{\nlabel=\"\";\n");
                strcat(j,NombreParticion4);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_8{\nlabel=\"\";\nLibre4[color=white];\n}");

                strcat(j,"subgraph cluster_3{\nlabel=\"\";\n");
                strcat(j,NombreParticion3);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_7{\nlabel=\"\";\nLibre3[color=white];\n}");

                strcat(j,"subgraph cluster_2{\nlabel=\"\";\n");
                strcat(j,NombreParticion2);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_6{\nlabel=\"\";\nLibre2[color=white];\n}");

                strcat(j,"subgraph cluster_1{\nlabel=\"\";\n");
                strcat(j,NombreParticion1);
                strcat(j,"[color=white];\n}");

                strcat(j,"subgraph cluster_5{\nlabel=\"\";\nLibre[color=white];\n}");

            }



            if(tipo41 == 'e')
            {

                posExt= 1;

            }
            else if(tipo42 == 'e')
            {

                posExt= 2;

            }
            else if(tipo43 == 'e')
            {

                posExt= 3;

            }
            else if(tipo44 == 'e')
            {

                posExt= 4;

            }

        }

        if(totalParticiones != 0)
        {
            strcat(j,"subgraph cluster_100{\nlabel=\"\";\n");
            strcat(j,"MBR[color=white];\n}");

        }



        char jj[5];
        sprintf(jj,"%d",posExt) ;





        if(lectura.mbr_partition_1.particion_status == '1' && lectura.mbr_partition_1.part_type=='e')
        {


            int posLeer = lectura.mbr_partition_1.part_start;
            int aumento = 0;
            int tt = 0;
            char w[10];
            sprintf(w,"%d",aumento);


            strcat(j,"subgraph cluster_");
            strcat(j,jj);
            strcat(j,"{\nlabel=\"");
            strcat(j,lectura.mbr_partition_1.part_name);                ;
            strcat(j,"\";\n");

            while(posLeer != -1 )
            {
                /**leo el ebr*/

                fseek(arch,posLeer,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);

                sprintf(w,"%d",aumento);

                if(EBRleida.part_status == '0' )
                {
                    strcat(j,"subgraph cluster_11");
                    strcat(j,w);
                    strcat(j,"{\nlabel=\"\";");
                    strcat(j,lectura.mbr_partition_1.part_name);

                    if(aumento != 0)
                    {
                        strcat(j,"70");
                        strcat(j,w);

                    }

                    strcat(j,"[color=white,shape=square,label=libre");
                    //  strcat(j,w);
                    strcat(j,"];\n");
                    strcat(j,"}");
                }

                if(EBRleida.part_status == '1')
                {

                    int medir = EBRleida.part_size + EBRleida.part_start;

                    if(EBRleida.part_next != -1 )
                    {

                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"[color=white,shape=square];\n");
                        strcat(j,"}");

                        if( (EBRleida.part_next  - medir) > 0 )
                        {


                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");
                        }


                    }
                    else
                    {


                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,lectura.mbr_partition_1.part_name);
                        strcat(j,w);
                        strcat(j,"[color=white,shape=square,");
                        strcat(j,"label=");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"];\n");
                        strcat(j,"}");

                        if( ((lectura.mbr_partition_1.part_size + lectura.mbr_partition_1.part_start) - medir) > 0 )
                        {

                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");

                        }

                    }


                }


                posLeer = EBRleida.part_next;
                aumento++;
            }
            strcat(j,"}");
        }


        else if(lectura.mbr_partition_2.particion_status == '1' && lectura.mbr_partition_2.part_type== 'e')
        {



            int posLeer = lectura.mbr_partition_2.part_start;
            int aumento = 0;
            int tt = 0;
            char w[10];
            sprintf(w,"%d",aumento);


            strcat(j,"subgraph cluster_");
            strcat(j,jj);
            strcat(j,"{\nlabel=\"");
            strcat(j,lectura.mbr_partition_2.part_name);                ;
            strcat(j,"\";\n");

            while(posLeer != -1 )
            {
                /**leo el ebr*/

                fseek(arch,posLeer,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);

                sprintf(w,"%d",aumento);

                if(EBRleida.part_status == '0' )
                {
                    strcat(j,"subgraph cluster_11");
                    strcat(j,w);
                    strcat(j,"{\nlabel=\"\";");
                    strcat(j,lectura.mbr_partition_2.part_name);

                    if(aumento != 0)
                    {
                        strcat(j,"70");
                        strcat(j,w);

                    }

                    strcat(j,"[color=white,shape=square,label=libre");
                    //  strcat(j,w);
                    strcat(j,"];\n");
                    strcat(j,"}");
                }

                if(EBRleida.part_status == '1')
                {

                    int medir = EBRleida.part_size + EBRleida.part_start;

                    if(EBRleida.part_next != -1 )
                    {

                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"[color=white,shape=square];\n");
                        strcat(j,"}");

                        if( (EBRleida.part_next  - medir) > 0 )
                        {


                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");
                        }


                    }
                    else
                    {


                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,lectura.mbr_partition_2.part_name);
                        strcat(j,w);
                        strcat(j,"[color=white,shape=square,");
                        strcat(j,"label=");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"];\n");
                        strcat(j,"}");

                        if( ((lectura.mbr_partition_2.part_size + lectura.mbr_partition_2.part_start) - medir) > 0 )
                        {

                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");

                        }

                    }


                }


                posLeer = EBRleida.part_next;
                aumento++;
            }
            strcat(j,"}");


        }


        else if(lectura.mbr_partition_3.particion_status == '1' && lectura.mbr_partition_3.part_type=='e')
        {
            int posLeer = lectura.mbr_partition_3.part_start;
            int aumento = 0;
            int tt = 0;
            char w[10];
            sprintf(w,"%d",aumento);


            strcat(j,"subgraph cluster_");
            strcat(j,jj);
            strcat(j,"{\nlabel=\"");
            strcat(j,lectura.mbr_partition_3.part_name);                ;
            strcat(j,"\";\n");

            while(posLeer != -1 )
            {
                /**leo el ebr*/

                fseek(arch,posLeer,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);

                sprintf(w,"%d",aumento);

                if(EBRleida.part_status == '0' )
                {
                    strcat(j,"subgraph cluster_11");
                    strcat(j,w);
                    strcat(j,"{\nlabel=\"\";");
                    strcat(j,lectura.mbr_partition_3.part_name);

                    if(aumento != 0)
                    {
                        strcat(j,"70");
                        strcat(j,w);

                    }

                    strcat(j,"[color=white,shape=square,label=libre");
                    //  strcat(j,w);
                    strcat(j,"];\n");
                    strcat(j,"}");
                }

                if(EBRleida.part_status == '1')
                {

                    int medir = EBRleida.part_size + EBRleida.part_start;

                    if(EBRleida.part_next != -1 )
                    {

                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"[color=white,shape=square];\n");
                        strcat(j,"}");

                        if( (EBRleida.part_next  - medir) > 0 )
                        {


                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");
                        }


                    }
                    else
                    {


                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,lectura.mbr_partition_3.part_name);
                        strcat(j,w);
                        strcat(j,"[color=white,shape=square,");
                        strcat(j,"label=");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"];\n");
                        strcat(j,"}");

                        if( ((lectura.mbr_partition_3.part_size + lectura.mbr_partition_3.part_start) - medir) > 0 )
                        {

                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");

                        }

                    }


                }


                posLeer = EBRleida.part_next;
                aumento++;
            }
            strcat(j,"}");



        }


        else  if(lectura.mbr_partition_4.particion_status == '1' && lectura.mbr_partition_4.part_type=='e')
        {


            int posLeer = lectura.mbr_partition_4.part_start;
            int aumento = 0;
            int tt = 0;
            char w[10];
            sprintf(w,"%d",aumento);


            strcat(j,"subgraph cluster_");
            strcat(j,jj);
            strcat(j,"{\nlabel=\"");
            strcat(j,lectura.mbr_partition_4.part_name);                ;
            strcat(j,"\";\n");

            while(posLeer != -1 )
            {
                /**leo el ebr*/

                fseek(arch,posLeer,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);

                sprintf(w,"%d",aumento);

                if(EBRleida.part_status == '0' )
                {
                    strcat(j,"subgraph cluster_11");
                    strcat(j,w);
                    strcat(j,"{\nlabel=\"\";");
                    strcat(j,lectura.mbr_partition_4.part_name);

                    if(aumento != 0)
                    {
                        strcat(j,"70");
                        strcat(j,w);

                    }

                    strcat(j,"[color=white,shape=square,label=libre");
                    //  strcat(j,w);
                    strcat(j,"];\n");
                    strcat(j,"}");
                }

                if(EBRleida.part_status == '1')
                {

                    int medir = EBRleida.part_size + EBRleida.part_start;

                    if(EBRleida.part_next != -1 )
                    {

                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"[color=white,shape=square];\n");
                        strcat(j,"}");

                        if( (EBRleida.part_next  - medir) > 0 )
                        {


                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");
                        }


                    }
                    else
                    {


                        strcat(j,"subgraph cluster_9");
                        strcat(j,w);
                        strcat(j,"{label=\"\";");
                        strcat(j,lectura.mbr_partition_4.part_name);
                        strcat(j,w);
                        strcat(j,"[color=white,shape=square,");
                        strcat(j,"label=");
                        strcat(j,EBRleida.part_name);
                        //strcat(j,w);
                        strcat(j,"];\n");
                        strcat(j,"}");

                        if( ((lectura.mbr_partition_4.part_size + lectura.mbr_partition_4.part_start) - medir) > 0 )
                        {

                            strcat(j,"subgraph cluster_11");
                            strcat(j,w);
                            strcat(j,"{label=\"\";");
                            strcat(j,"libre");
                            strcat(j,w);
                            strcat(j,"[color=white,shape=square,label=libre");
                            strcat(j,"];\n");
                            strcat(j,"}");

                        }

                    }


                }


                posLeer = EBRleida.part_next;
                aumento++;
            }
            strcat(j,"}");


        }





        strcat(j,"}}");



    }
    else
    {
        printf("Error en Lectura del MBR  ");
    }
    fclose(arch);

    ///leerMBR(ruta);


    ///printf("Dir: %s\n",dir);

    char comand1[200];
    strcpy(comand1,"mkdir -p ");
    strcat(comand1,"\"");
    strcat(comand1,dir);
    strcat(comand1,"\"");

    char comand2[200];
    strcpy(comand2,"rm -fr ");
    strcat(comand2,"\"");
    strcat(comand2,dir);
    strcat(comand2,"\"");

    system(comand1);
    system(comand2);



    char comand3[200];
    strcpy(comand3,dir);


    FILE *arch2=fopen("/home/paublo/Disco.dot","wb+");
    if (arch2!=NULL)
    {

        fwrite(&j,sizeof(char),strlen(j),arch2);

    }
    else
    {
        printf("Error al Crear el Reporte de MBR\n");
    }
    fclose(arch2);

    char comand4[200];
    strcpy(comand4,"dot -Tjpg ");
    strcat(comand4,"/home/paublo/Disco.dot");
    strcat(comand4," -o ");
    strcat(comand4,"\"");
    strcat(comand4,dir);
    strcat(comand4,"\"");
    ///printf("Este comando se va ejectuar:    %s\n",comand4);
    ///strcpy(comand4,"dot -Tpng /home/paublo/MBR.dot -o MBR.png");
    system(comand4);


}


void ReporteDeMBR(char *ruta, char *dir)
{
    printf("Reporte de MBR para %s , generado exitosamente\n",ruta);
    char j[100000] = "graph {\n splines=line;\n subgraph cluster_0 { label= \"";
    strcat(j,ruta);
    strcat(j,"\nReporte MBR\";\n");
    int logicas = 0;
    char logicasTexto[10];

    FILE *arch = fopen(ruta,"rb+");
    char logic[10000];
    strcpy(logic,"");

    if (arch!=NULL)
    {

        MBRdisco lectura;
        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);
        EBR EBRleida;


        struct tm *tlocal = localtime(&lectura.mbr_fecha_creacion);
        char output[128];
        strftime(output,128,"%d/%m/%y %H:%M:%S",tlocal);


        int signature=lectura.mbr_disk_signature;
        char signatureString[10];
        int Tama=lectura.mbr_tamanio;
        char TamaString[15];
        sprintf(signatureString,"%d",signature);
        sprintf(TamaString,"%d",Tama);

        strcat(j,"\"MBR Signature:               ");
        strcat(j,signatureString);
        strcat(j,"\nMBR Size:                     ");
        strcat(j,TamaString);
        strcat(j,"\nMBR Date/Hour:                ");
        strcat(j,output);



        char EstadoLeido[5];
        char TipodePart[5];
        char TipoDeAjuste[5];
        char ByteInicioString[20];
        char TamanioParticionString[20];
        char Next[20];
        char conteoEBR[4];

        if(lectura.mbr_partition_1.part_start != -1 && lectura.mbr_partition_1.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            sprintf(EstadoLeido,"%c",lectura.mbr_partition_1.particion_status);
            sprintf(TipodePart,"%c",lectura.mbr_partition_1.part_type);
            sprintf(TipoDeAjuste,"%c",lectura.mbr_partition_1.part_fit);
            sprintf(ByteInicioString,"%d",lectura.mbr_partition_1.part_start);
            sprintf(TamanioParticionString,"%d",lectura.mbr_partition_1.part_size);

            strcat(j,"\nParticion 1:");
            strcat(j,"\nEstado de la particion:       ");
            strcat(j,EstadoLeido);
            strcat(j,"\nTipo de particion:            ");
            strcat(j,TipodePart);
            strcat(j,"\nTipo de Ajuste:               ");
            strcat(j,TipoDeAjuste);
            strcat(j,"\nByte de Inicio:               ");
            strcat(j,ByteInicioString);
            strcat(j,"\nTamanio de Particion:         ");
            strcat(j,TamanioParticionString);
            strcat(j,"\nNombre de Particion:          ");
            strcat(j,lectura.mbr_partition_1.part_name);

            if(lectura.mbr_partition_1.part_type == 'e')
            {

                int Leer = 0;
                int posLeer = lectura.mbr_partition_1.part_start;
                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,posLeer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    sprintf(EstadoLeido,"%c",EBRleida.part_status);
                    sprintf(Next,"%d",EBRleida.part_next);
                    sprintf(TipoDeAjuste,"%c",EBRleida.part_fit);
                    sprintf(ByteInicioString,"%d",EBRleida.part_start);
                    sprintf(TamanioParticionString,"%d",EBRleida.part_size);
                    sprintf(conteoEBR,"%d",logicas+1);
                    //printf("ByteInicio %s\n",ByteInicioString);

                    /**escribo codigo graphviz para un cluster_1x */
                    strcat(logic,"subgraph cluster_1");
                    strcat(logic,conteoEBR);
                    strcat(logic," { label= ");
                    strcat(logic,"\"EBR:");
                    strcat(logic," No. ");
                    strcat(logic,conteoEBR);
                    strcat(logic,"\";\n");
                    strcat(logic,"\"");
                    strcat(logic,"Estado de la particion:     ");
                    strcat(logic,EstadoLeido);
                    strcat(logic,"\nTipo de Ajuste:             ");
                    strcat(logic,TipoDeAjuste);
                    strcat(logic,"\nByte de Inicio:             ");
                    strcat(logic,ByteInicioString);
                    strcat(logic,"\nInicia Siguiente:       ");
                    strcat(logic,Next);
                    strcat(logic,"\nTamanio:       ");
                    strcat(logic,TamanioParticionString);
                    strcat(logic,"\nNombre de Particion:        ");
                    strcat(logic,EBRleida.part_name);
                    strcat(logic,"\"[shape=rectangle,width=5,heigth=0.5,textalineation=left];}");
                    logicas++;
                    Leer = EBRleida.part_next;
                    posLeer = Leer;

                }

            }

        }


        if(lectura.mbr_partition_2.part_start != -1 && lectura.mbr_partition_2.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            sprintf(EstadoLeido,"%c",lectura.mbr_partition_2.particion_status);
            sprintf(TipodePart,"%c",lectura.mbr_partition_2.part_type);
            sprintf(TipoDeAjuste,"%c",lectura.mbr_partition_2.part_fit);
            sprintf(ByteInicioString,"%d",lectura.mbr_partition_2.part_start);
            sprintf(TamanioParticionString,"%d",lectura.mbr_partition_2.part_size);

            strcat(j,"\nParticion 2:");
            strcat(j,"\nEstado de la particion:       ");
            strcat(j,EstadoLeido);
            strcat(j,"\nTipo de particion:            ");
            strcat(j,TipodePart);
            strcat(j,"\nTipo de Ajuste:               ");
            strcat(j,TipoDeAjuste);
            strcat(j,"\nByte de Inicio:               ");
            strcat(j,ByteInicioString);
            strcat(j,"\nTamanio de Particion:         ");
            strcat(j,TamanioParticionString);
            strcat(j,"\nNombre de Particion:          ");
            strcat(j,lectura.mbr_partition_2.part_name);

            if(lectura.mbr_partition_2.part_type == 'e')
            {

                int Leer = 0;
                int posLeer = lectura.mbr_partition_2.part_start;
                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,posLeer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    sprintf(EstadoLeido,"%c",EBRleida.part_status);
                    sprintf(Next,"%d",EBRleida.part_next);
                    sprintf(TipoDeAjuste,"%c",EBRleida.part_fit);
                    sprintf(ByteInicioString,"%d",EBRleida.part_start);
                    sprintf(TamanioParticionString,"%d",EBRleida.part_size);
                    sprintf(conteoEBR,"%d",logicas+1);
                    //printf("ByteInicio %s\n",ByteInicioString);

                    /**escribo codigo graphviz para un cluster_1x */
                    strcat(logic,"subgraph cluster_1");
                    strcat(logic,conteoEBR);
                    strcat(logic," { label= ");
                    strcat(logic,"\"EBR:");
                    strcat(logic," No. ");
                    strcat(logic,conteoEBR);
                    strcat(logic,"\";\n");
                    strcat(logic,"\"");
                    strcat(logic,"Estado de la particion:     ");
                    strcat(logic,EstadoLeido);
                    strcat(logic,"\nTipo de Ajuste:             ");
                    strcat(logic,TipoDeAjuste);
                    strcat(logic,"\nByte de Inicio:             ");
                    strcat(logic,ByteInicioString);
                    strcat(logic,"\nInicia Siguiente:       ");
                    strcat(logic,Next);
                    strcat(logic,"\nTamanio:       ");
                    strcat(logic,TamanioParticionString);
                    strcat(logic,"\nNombre de Particion:        ");
                    strcat(logic,EBRleida.part_name);
                    strcat(logic,"\"[shape=rectangle,width=5,heigth=0.5,textalineation=left];}");
                    logicas++;
                    Leer = EBRleida.part_next;
                    posLeer = Leer;

                }

            }

        }

        if(lectura.mbr_partition_3.part_start != -1 && lectura.mbr_partition_3.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {
            sprintf(EstadoLeido,"%c",lectura.mbr_partition_3.particion_status);
            sprintf(TipodePart,"%c",lectura.mbr_partition_3.part_type);
            sprintf(TipoDeAjuste,"%c",lectura.mbr_partition_3.part_fit);
            sprintf(ByteInicioString,"%d",lectura.mbr_partition_3.part_start);
            sprintf(TamanioParticionString,"%d",lectura.mbr_partition_3.part_size);

            strcat(j,"\nParticion 3:");
            strcat(j,"\nEstado de la particion:       ");
            strcat(j,EstadoLeido);
            strcat(j,"\nTipo de particion:            ");
            strcat(j,TipodePart);
            strcat(j,"\nTipo de Ajuste:               ");
            strcat(j,TipoDeAjuste);
            strcat(j,"\nByte de Inicio:               ");
            strcat(j,ByteInicioString);
            strcat(j,"\nTamanio de Particion:         ");
            strcat(j,TamanioParticionString);
            strcat(j,"\nNombre de Particion:          ");
            strcat(j,lectura.mbr_partition_3.part_name);


            if(lectura.mbr_partition_3.part_type == 'e')
            {
                ///printf("Hola esto es para las extendidas");

                int Leer = 0;
                int posLeer = lectura.mbr_partition_3.part_start;
                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,posLeer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    sprintf(EstadoLeido,"%c",EBRleida.part_status);
                    sprintf(Next,"%d",EBRleida.part_next);
                    sprintf(TipoDeAjuste,"%c",EBRleida.part_fit);
                    sprintf(ByteInicioString,"%d",EBRleida.part_start);
                    sprintf(TamanioParticionString,"%d",EBRleida.part_size);
                    sprintf(conteoEBR,"%d",logicas+1);
                    ////printf("ByteInicio %s\n",ByteInicioString);

                    /**escribo codigo graphviz para un cluster_1x */
                    strcat(logic,"subgraph cluster_1");
                    strcat(logic,conteoEBR);
                    strcat(logic," { label= ");
                    strcat(logic,"\"EBR:");
                    strcat(logic," No. ");
                    strcat(logic,conteoEBR);
                    strcat(logic,"\";\n");
                    strcat(logic,"\"");
                    strcat(logic,"Estado de la particion:     ");
                    strcat(logic,EstadoLeido);
                    strcat(logic,"\nTipo de Ajuste:             ");
                    strcat(logic,TipoDeAjuste);
                    strcat(logic,"\nByte de Inicio:             ");
                    strcat(logic,ByteInicioString);
                    strcat(logic,"\nInicia Siguiente:       ");
                    strcat(logic,Next);
                    strcat(logic,"\nTamanio:       ");
                    strcat(logic,TamanioParticionString);
                    strcat(logic,"\nNombre de Particion:        ");
                    strcat(logic,EBRleida.part_name);
                    strcat(logic,"\"[shape=rectangle,width=5,heigth=0.5,textalineation=left];}");
                    logicas++;
                    Leer = EBRleida.part_next;
                    posLeer = Leer;

                }

            }

        }

        if(lectura.mbr_partition_4.part_start != -1 && lectura.mbr_partition_4.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            sprintf(EstadoLeido,"%c",lectura.mbr_partition_4.particion_status);
            sprintf(TipodePart,"%c",lectura.mbr_partition_4.part_type);
            sprintf(TipoDeAjuste,"%c",lectura.mbr_partition_4.part_fit);
            sprintf(ByteInicioString,"%d",lectura.mbr_partition_4.part_start);
            sprintf(TamanioParticionString,"%d",lectura.mbr_partition_4.part_size);

            strcat(j,"\nParticion 4:");
            strcat(j,"\nEstado de la particion:       ");
            strcat(j,EstadoLeido);
            strcat(j,"\nTipo de particion:            ");
            strcat(j,TipodePart);
            strcat(j,"\nTipo de Ajuste:               ");
            strcat(j,TipoDeAjuste);
            strcat(j,"\nByte de Inicio:               ");
            strcat(j,ByteInicioString);
            strcat(j,"\nTamanio de Particion:         ");
            strcat(j,TamanioParticionString);
            strcat(j,"\nNombre de Particion:          ");
            strcat(j,lectura.mbr_partition_4.part_name);

            if(lectura.mbr_partition_4.part_type == 'e')
            {
                ///  printf("Hola esto es para las extendidas");

                int Leer = 0;
                int posLeer = lectura.mbr_partition_4.part_start;
                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,posLeer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    sprintf(EstadoLeido,"%c",EBRleida.part_status);
                    sprintf(Next,"%d",EBRleida.part_next);
                    sprintf(TipoDeAjuste,"%c",EBRleida.part_fit);
                    sprintf(ByteInicioString,"%d",EBRleida.part_start);
                    sprintf(TamanioParticionString,"%d",EBRleida.part_size);
                    sprintf(conteoEBR,"%d",logicas+1);
                    ////    printf("ByteInicio %s\n",ByteInicioString);

                    /**escribo codigo graphviz para un cluster_1x */
                    strcat(logic,"subgraph cluster_1");
                    strcat(logic,conteoEBR);
                    strcat(logic," { label= ");
                    strcat(logic,"\"EBR:");
                    strcat(logic," No. ");
                    strcat(logic,conteoEBR);
                    strcat(logic,"\";\n");
                    strcat(logic,"\"");
                    strcat(logic,"Estado de la particion:     ");
                    strcat(logic,EstadoLeido);
                    strcat(logic,"\nTipo de Ajuste:             ");
                    strcat(logic,TipoDeAjuste);
                    strcat(logic,"\nByte de Inicio:             ");
                    strcat(logic,ByteInicioString);
                    strcat(logic,"\nInicia Siguiente:       ");
                    strcat(logic,Next);
                    strcat(logic,"\nTamanio:       ");
                    strcat(logic,TamanioParticionString);
                    strcat(logic,"\nNombre de Particion:        ");
                    strcat(logic,EBRleida.part_name);
                    strcat(logic,"\"[shape=rectangle,width=5,heigth=0.5,textalineation=left];}");
                    logicas++;
                    Leer = EBRleida.part_next;
                    posLeer =  Leer;

                }

            }


        }


    }
    else
    {
        printf("Error en Lectura del MBR  ");
    }
    fclose(arch);
    strcat(j,"\"[shape=rectangle,width=5,heigth=0.5,textalineation=left];");
    strcat(j,"}");
    strcat(j,logic);
    strcat(j,"}");


    ///printf("Dir: %s\n",dir);

    char comand1[200];
    strcpy(comand1,"mkdir -p ");
    strcat(comand1,"\"");
    strcat(comand1,dir);
    strcat(comand1,"\"");

    char comand2[200];
    strcpy(comand2,"rm -fr ");
    strcat(comand2,"\"");
    strcat(comand2,dir);
    strcat(comand2,"\"");

    system(comand1);
    system(comand2);



    char comand3[200];
    strcpy(comand3,dir);


    FILE *arch2=fopen("/home/paublo/MBR.dot","wb+");
    if (arch2!=NULL)
    {

        fwrite(&j,sizeof(char),strlen(j),arch2);

    }
    else
    {
        printf("Error al Crear el Reporte de MBR\n");
    }
    fclose(arch2);

    char comand4[200];
    strcpy(comand4,"dot -Tjpg ");
    strcat(comand4,"/home/paublo/MBR.dot");
    strcat(comand4," -o ");
    strcat(comand4,"\"");
    strcat(comand4,dir);
    strcat(comand4,"\"");
    ///printf("Este comando se va ejectuar:    %s\n",comand4);
    ///strcpy(comand4,"dot -Tpng /home/paublo/MBR.dot -o MBR.png");
    system(comand4);


}


void RedimensionarParticiones(char unidad,int cantidad,char* nombre,char *ruta)
{
    int tamanioOficial = 0;

    int multi=1;



    if(unidad == 'k')
    {
        multi=1;
        //  printf("k\n");
        tamanioOficial= cantidad*1024;
    }
    else if(unidad == 'm')
    {
        multi=1024;
        //printf("m\n");
        tamanioOficial= 1024*1024*cantidad;
    }
    else
    {
        //printf("b\n");
        tamanioOficial= cantidad;
    }



    ///estas las vamos a usar para calcular el byte de inicio de la particion nueva
    int inicio1 = -1;
    int tamanio1= -1;
    int inicio2= -1;
    int tamanio2= -1;
    int inicio3= -1;
    int tamanio3= -1;
    int inicio4= -1;
    int tamanio4= -1;
    int fin1= -1;
    int fin2= -1;
    int fin3= -1;
    int fin4= -1;
    int totalParticiones=0;
    int parModifi = 0;
    int ByteFinalNuevo = 0;
    int extmaster = 0;
    int logicaMOdificar = 0;
    int FinExtendida = 0;

    int inicioPart21;
    int inicioPart22;
    int finPart21;
    int finPart22;







    FILE *arch = fopen(ruta,"rb+");
    if (arch!=NULL)
    {

        MBRdisco lectura;
        EBR EBRleida;
        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);

        /**Obtenemos todos los valores de las particiones */

        if(lectura.mbr_partition_1.particion_status == '1')
        {
            totalParticiones++;
            tamanio1=lectura.mbr_partition_1.part_size;
            inicio1=lectura.mbr_partition_1.part_start;
            fin1=inicio1+tamanio1;

            if(!strcmp(lectura.mbr_partition_1.part_name,nombre))
            {
                printf("Hallamos la particion que vamos a redimensionar\n");
                parModifi = 1;
            }

        }

        if(lectura.mbr_partition_2.particion_status == '1')
        {
            totalParticiones++;
            tamanio2=lectura.mbr_partition_2.part_size;
            inicio2=lectura.mbr_partition_2.part_start;
            fin2=inicio2+tamanio2;

            if(!strcmp(lectura.mbr_partition_2.part_name,nombre))
            {

                printf("Hallamos la particion que vamos a redimensionar\n");
                parModifi = 2;

            }

        }

        if(lectura.mbr_partition_3.particion_status == '1')
        {
            totalParticiones++;
            tamanio3=lectura.mbr_partition_3.part_size;
            inicio3=lectura.mbr_partition_3.part_start;
            fin3=inicio3+tamanio3;

            if(!strcmp(lectura.mbr_partition_3.part_name,nombre))
            {

                printf("Hallamos la particion que vamos a redimensionar\n");
                parModifi = 3;

            }

        }

        if(lectura.mbr_partition_4.particion_status == '1')
        {
            totalParticiones++;
            tamanio4=lectura.mbr_partition_4.part_size;
            inicio4=lectura.mbr_partition_4.part_start;
            fin4=inicio4+tamanio4;

            if(!strcmp(lectura.mbr_partition_4.part_name,nombre))
            {

                printf("Hallamos la particion que vamos a redimensionar\n");

                parModifi = 4;
            }

        }


        /**vamos a ver si es logica la que vamos a redimensionar ahora*/

        if(lectura.mbr_partition_1.particion_status == '1' && lectura.mbr_partition_1.part_type == 'e' && parModifi == 0)
        {

            fseek(arch,lectura.mbr_partition_1.part_start,SEEK_SET);
            fread(&EBRleida,sizeof(EBR),1,arch);

            while(EBRleida.part_next != -1)
            {
                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 1;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin1;
                    break;
                }

                fseek(arch,EBRleida.part_next,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);
            }

            if(EBRleida.part_next == -1)
            {

                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 1;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin1;

                }
            }

        }

        if(lectura.mbr_partition_2.particion_status == '1' && lectura.mbr_partition_2.part_type == 'e' && parModifi == 0)
        {

            fseek(arch,lectura.mbr_partition_2.part_start,SEEK_SET);
            fread(&EBRleida,sizeof(EBR),1,arch);

            while(EBRleida.part_next != -1)
            {
                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 2;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin2;
                    break;
                }

                fseek(arch,EBRleida.part_next,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);
            }

            if(EBRleida.part_next == -1)
            {

                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 2;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin2;

                }
            }

        }


        if(lectura.mbr_partition_3.particion_status == '1' && lectura.mbr_partition_3.part_type == 'e' && parModifi == 0)
        {

            fseek(arch,lectura.mbr_partition_3.part_start,SEEK_SET);
            fread(&EBRleida,sizeof(EBR),1,arch);

            while(EBRleida.part_next != -1)
            {
                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 3;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin3;
                    break;
                }

                fseek(arch,EBRleida.part_next,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);
            }

            if(EBRleida.part_next == -1)
            {

                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 3;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin3;

                }
            }

        }


        if(lectura.mbr_partition_4.particion_status == '1' && lectura.mbr_partition_4.part_type == 'e' && parModifi == 0)
        {

            fseek(arch,lectura.mbr_partition_4.part_start,SEEK_SET);
            fread(&EBRleida,sizeof(EBR),1,arch);

            while(EBRleida.part_next != -1)
            {
                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 4;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin4;
                    break;
                }

                fseek(arch,EBRleida.part_next,SEEK_SET);
                fread(&EBRleida,sizeof(EBR),1,arch);
            }

            if(EBRleida.part_next == -1)
            {

                if(!strcmp(EBRleida.part_name,nombre))
                {
                    printf("Particion logica a redimensionar hallada \n");
                    parModifi = 7;
                    extmaster = 4;
                    logicaMOdificar = EBRleida.part_start;
                    FinExtendida = fin4;

                }
            }

        }



        if(cantidad < 0) ///&& (finPart1 - inicioPart1) > sizeof(MBRdisco)
        {

            if(parModifi == 1 && lectura.mbr_partition_1.part_type == 'p' ||  parModifi == 1 && lectura.mbr_partition_1.part_type == 'e')
            {
                if((lectura.mbr_partition_1.part_size+tamanioOficial) > 0)   ///entre el fin de la particion y el fin del disco cabe un aumento
                {
                    int tamAnterior = lectura.mbr_partition_1.part_size;
                    lectura.mbr_partition_1.part_size = lectura.mbr_partition_1.part_size+tamanioOficial;
                    printf("Espacio reducido de %d af %d\n",tamAnterior,lectura.mbr_partition_1.part_size);
                    fseek(arch,0,SEEK_SET);
                    fwrite(&lectura,sizeof(MBRdisco),1,arch);
                    fclose(arch);
                    return;

                }
                else
                {
                    printf("No se puede disminuir porque queda espacio negativo \n");
                }

            }
            else if(parModifi == 1 && lectura.mbr_partition_1.part_type == 'p' ||  parModifi == 1 && lectura.mbr_partition_1.part_type == 'e')
            {
                if((lectura.mbr_partition_1.part_size+tamanioOficial) > 0)   ///entre el fin de la particion y el fin del disco cabe un aumento
                {
                    int tamAnterior = lectura.mbr_partition_1.part_size;
                    lectura.mbr_partition_1.part_size = lectura.mbr_partition_1.part_size+tamanioOficial;
                    printf("Espacio reducido de %d a %d\n",tamAnterior,lectura.mbr_partition_1.part_size);
                    fseek(arch,0,SEEK_SET);
                    fwrite(&lectura,sizeof(MBRdisco),1,arch);
                    fclose(arch);
                    return;

                }
                else
                {
                    printf("No se puede disminuir porque queda espacio negativo \n");
                }

            }
            else if(parModifi == 7)
            {


                if((EBRleida.part_size+tamanioOficial) > 0)   ///entre el fin de la particion y el fin del disco cabe un aumento
                {
                    ///ByteFinalNuevo = fin1+tamanioOficial;
                    int tamAnterior = EBRleida.part_size;
                    EBRleida.part_size = EBRleida.part_size+tamanioOficial;
                    printf("Espacio reducido de %d a %d\n",tamAnterior,EBRleida.part_size);
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);
                    fclose(arch);
                    return;

                }
                else
                {
                    printf("No se puede disminuir porque queda espacio negativo \n");
                }





            }



        }
        else if(cantidad > 0)
        {

            if(totalParticiones == 1)
            {

                if(parModifi == 1)
                {


                    if(fin1 + tamanioOficial > lectura.mbr_tamanio)
                    {

                        printf("No existe suficiente espacio en el disco para hacer esto\n");
                        return;

                    }
                    else
                    {

                        int tamanioAnterior = lectura.mbr_partition_1.part_size;
                        lectura.mbr_partition_1.part_size = lectura.mbr_partition_1.part_size + tamanioOficial;
                        printf("La particion se ha agrandado de %d a %d",tamanioAnterior,lectura.mbr_partition_1.part_size);
                        fseek(arch,0,SEEK_SET);
                        fwrite(&lectura,sizeof(MBRdisco),1,arch);
                        fclose(arch);
                        return;
                    }

                }
                else if(parModifi == 2)
                {


                    if(fin2 + tamanioOficial > lectura.mbr_tamanio)
                    {

                        printf("No existe suficiente espacio en el disco para hacer esto\n");
                        return;

                    }
                    else
                    {

                        int tamanioAnterior = lectura.mbr_partition_2.part_size;
                        lectura.mbr_partition_2.part_size = lectura.mbr_partition_2.part_size + tamanioOficial;
                        printf("La particion se ha agrandado de %d a %d",tamanioAnterior,lectura.mbr_partition_2.part_size);
                        fseek(arch,0,SEEK_SET);
                        fwrite(&lectura,sizeof(MBRdisco),1,arch);
                        fclose(arch);
                        return;
                    }

                }
                else if(parModifi == 3)
                {


                    if(fin3 + tamanioOficial > lectura.mbr_tamanio)
                    {

                        printf("No existe suficiente espacio en el disco para hacer esto\n");
                        return;

                    }
                    else
                    {

                        int tamanioAnterior = lectura.mbr_partition_3.part_size;
                        lectura.mbr_partition_3.part_size = lectura.mbr_partition_3.part_size + tamanioOficial;
                        printf("La particion se ha agrandado de %d a %d",tamanioAnterior,lectura.mbr_partition_3.part_size);
                        fseek(arch,0,SEEK_SET);
                        fwrite(&lectura,sizeof(MBRdisco),1,arch);
                        fclose(arch);
                        return;
                    }

                }
                else if(parModifi == 4)
                {


                    if(fin4 + tamanioOficial > lectura.mbr_tamanio)
                    {

                        printf("No existe suficiente espacio en el disco para hacer esto\n");
                        return;

                    }
                    else
                    {
                        int tamanioAnterior = lectura.mbr_partition_4.part_size;
                        lectura.mbr_partition_4.part_size = lectura.mbr_partition_4.part_size + tamanioOficial;
                        printf("La particion se ha agrandado de %d a %d",tamanioAnterior,lectura.mbr_partition_4.part_size);
                        fseek(arch,0,SEEK_SET);
                        fwrite(&lectura,sizeof(MBRdisco),1,arch);
                        fclose(arch);
                        return;

                    }

                }
                else if(parModifi == 7)
                {

                    fseek(arch,logicaMOdificar,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);

                    if(EBRleida.part_next == -1){

                        if( (EBRleida.part_size + EBRleida.part_start  + tamanioOficial) <= FinExtendida){

                            int tamanioAnterior = EBRleida.part_size;
                            EBRleida.part_size = EBRleida.part_size + tamanioOficial;
                            printf("La particion logica ha sido aumentada de %d a %d",tamanioAnterior,EBRleida.part_size);
                            fseek(arch,0,SEEK_SET);
                            fwrite(&lectura,sizeof(MBRdisco),1,arch);
                            fclose(arch);
                            return;

                        }else{

                            printf("No existe suficiente espacio en la particion extendida para hacer esto \n");
                            return;

                        }

                    }else{

                        fseek(arch,logicaMOdificar,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);

                        EBR leida2;
                        fseek(arch,EBRleida.part_next,SEEK_SET);
                        fread(&leida2,sizeof(EBR),1,arch);


                        if( (EBRleida.part_size + EBRleida.part_start  + tamanioOficial) <= leida2.part_start){

                            int tamanioAnterior = EBRleida.part_size;
                            EBRleida.part_size = EBRleida.part_size + tamanioOficial;
                            printf("La particion logica ha sido aumentada de %d a %d",tamanioAnterior,EBRleida.part_size);
                            fseek(arch,EBRleida.part_start,SEEK_SET);
                            fwrite(&EBRleida,sizeof(EBR),1,arch);
                            fclose(arch);
                            return;

                        }else{

                            printf("No existe suficiente espacio despues de la particion para agrandarla %d\n",EBRleida.part_size);
                            return;

                        }

                    }



                }

            }


            else if(totalParticiones == 2){





            }


    }
    else
    {
        printf("Error en Lectura del MBR  ");
    }

    fclose(arch);




}

}


int verificarNombreParticion(char* nombre, char* ruta)  ///1 ya existe, 0 no existe
{



    FILE *arch = fopen(ruta,"rb");
    if (arch!=NULL)
    {

        MBRdisco lectura;
        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);
        EBR EBRleida;



        if(lectura.mbr_partition_1.part_start != -1 && lectura.mbr_partition_1.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(nombre,lectura.mbr_partition_1.part_name))
            {


                printf("La particion existe %s\n",nombre);
                fclose(arch);
                return 1;

            }
            else if(lectura.mbr_partition_1.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_1.part_start;

                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    if(!strcmp(EBRleida.part_name,nombre) && EBRleida.part_status == '1')
                    {
                        printf("La particion logica existe %s\n",nombre);
                        fclose(arch);
                        return 1;
                    }
                    else
                    {
                        Leer = EBRleida.part_next;
                    }


                }

            }

        }


        if(lectura.mbr_partition_2.part_start != -1 && lectura.mbr_partition_2.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(nombre,lectura.mbr_partition_2.part_name))
            {


                printf("La particion existe\n");
                fclose(arch);
                return 1;

            }
            else if(lectura.mbr_partition_2.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_2.part_start;

                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    if(!strcmp(EBRleida.part_name,nombre) && EBRleida.part_status == '1')
                    {
                        printf("La particion existe\n");
                        fclose(arch);
                        return 1;
                    }
                    else
                    {
                        Leer = EBRleida.part_next;
                    }


                }

            }

        }


        if(lectura.mbr_partition_3.part_start != -1 && lectura.mbr_partition_3.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(nombre,lectura.mbr_partition_3.part_name))
            {


                printf("La particion existe\n");
                return 1;

            }
            else if(lectura.mbr_partition_3.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_3.part_start;

                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    if(!strcmp(EBRleida.part_name,nombre) && EBRleida.part_status == '1')
                    {
                        printf("La particion existe\n");
                        fclose(arch);
                        return 1;
                    }
                    else
                    {
                        Leer = EBRleida.part_next;
                    }


                }

            }

        }


        if(lectura.mbr_partition_4.part_start != -1 && lectura.mbr_partition_4.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(nombre,lectura.mbr_partition_4.part_name))
            {


                printf("La particion existe\n");
                return 1;

            }
            else if(lectura.mbr_partition_4.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_4.part_start;

                while(Leer != -1 )
                {
                    /**leo el ebr*/
                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    /**almaceno los valores correspondientes al ebr*/
                    if(!strcmp(EBRleida.part_name,nombre) && EBRleida.part_status == '1')
                    {
                        printf("La particion existe\n");
                        fclose(arch);
                        return 1;
                    }
                    else
                    {
                        Leer = EBRleida.part_next;
                    }


                }

            }

        }




    }
    else
    {
        printf("Error en Lectura del MBR  \n");
        return;
    }
    fclose(arch);


    return 0;

}



void EliminarParticionFast(char *nombre, char *ruta)
{
    FILE *arch = fopen(ruta,"rb+");


    if (arch!=NULL)
    {


        MBRdisco lectura;
        EBR EBRleida;
        int byteInicio = 0;

        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);


        if(lectura.mbr_partition_1.particion_status != '0')
        {

            if(!strcmp(lectura.mbr_partition_1.part_name,nombre))
            {

              ///  printf("La primera es la que quiero eliminar\n");
            ///    printf("Nombre:      %s\n",lectura.mbr_partition_1.part_name);
                lectura.mbr_partition_1.particion_status = '0';

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Fast\n");
                return;
            }
            else if(lectura.mbr_partition_1.part_type == 'e')  ///si es una extendida
            {


                int Leer = lectura.mbr_partition_1.part_start;
                int logicleidas=0;
                int SiguienteAhora = 0;
                int TamanioLogica =0;
                int InicioLogica = 0;
                int halle = 0;

                while(Leer != -1)
                {

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    logicleidas++;
                    TamanioLogica = EBRleida.part_size;
                    InicioLogica = EBRleida.part_start;
                    SiguienteAhora = EBRleida.part_next;

                    if(!strcmp(EBRleida.part_name,nombre))
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion Logica %s de Forma Fast\n",nombre);
                        halle = 1;
                        break;
                    }


                    if(EBRleida.part_next == -1 && !strcmp(EBRleida.part_name,nombre) )
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion logica %s de Forma Fast\n",nombre);
                        halle = 1;

                        break;

                    }

                    Leer = EBRleida.part_next;

                }

                // printf("Parte logica 1 \n");
                // printf("Tamanio Logica %d\n",TamanioLogica);
                // printf("Inicio Logica  %d\n",InicioLogica);
                // printf("Siguiente ahora %d\n",SiguienteAhora);
                // printf("Leer %d\n",Leer);
                // printf("logicleidas %d\n",logicleidas);


                if(logicleidas > 1 && halle == 1)
                {
                    ///printf("Entre a mayor a 1 \n");

                    // fseek(arch,Leer,SEEK_SET);
                    //fread(&EBRleida,sizeof(EBR),1,arch);
                    //fwrite(&EBRleida,sizeof(EBR),1,arch);
                    int tt = 0;
                    Leer = lectura.mbr_partition_1.part_start;

                    while(tt != logicleidas-1)
                    {
                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                    ///    printf("El nombre de esta es %s\n",EBRleida.part_name);
                        Leer = EBRleida.part_next;
                        tt++;
                    }

                ////    printf("Se modifica el siguiente de %s\n",EBRleida.part_name);
                    EBRleida.part_next = SiguienteAhora;
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);


                }

            }


        }


        if(lectura.mbr_partition_2.particion_status != '0')
        {

            if(!strcmp(lectura.mbr_partition_2.part_name,nombre))
            {

              ///  printf("aca si\n");
            ///printf("La 2 es la que quiero eliminar\n");
                printf("Nombre:      %s\n",lectura.mbr_partition_2.part_name);
                lectura.mbr_partition_2.particion_status = '0';

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Fast\n");
                return;
            }
            else if(lectura.mbr_partition_2.part_type == 'e')   ///si es una extendida
            {

               /// printf("osea que putas\n");
                int Leer = lectura.mbr_partition_2.part_start;
                int logicleidas=0;
                int SiguienteAhora = 0;
                int TamanioLogica =0;
                int InicioLogica = 0;
                int halle = 0;

                while(Leer != -1)
                {

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    logicleidas++;
                    TamanioLogica = EBRleida.part_size;
                    InicioLogica = EBRleida.part_start;
                    SiguienteAhora = EBRleida.part_next;

                    if(!strcmp(EBRleida.part_name,nombre))
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        halle = 1;
                        printf("Eliminada la particion Logica %s de Forma Fast\n",nombre);
                        break;
                    }


                    if(EBRleida.part_next == -1 && !strcmp(EBRleida.part_name,nombre) )
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        halle = 1;
                        printf("Eliminada la particion logica %s de Forma Fast\n",nombre);
                        break;

                    }

                    Leer = EBRleida.part_next;

                }

                //    printf("Parte logica 2 \n");
                //   printf("Tamanio Logica %d\n",TamanioLogica);
                //  printf("Inicio Logica  %d\n",InicioLogica);
                // printf("Siguiente ahora %d\n",SiguienteAhora);
                // printf("Leer %d\n",Leer);
                // printf("logicleidas %d\n",logicleidas);


                if(logicleidas > 1 && halle == 1)
                {
                  ///  printf("Entre a mayor a 1 \n");

                    // fseek(arch,Leer,SEEK_SET);
                    //fread(&EBRleida,sizeof(EBR),1,arch);
                    //fwrite(&EBRleida,sizeof(EBR),1,arch);
                    int tt = 0;
                    Leer = lectura.mbr_partition_2.part_start;

                    while(tt != logicleidas-1)
                    {
                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                  ///      printf("El nombre de esta es %s\n",EBRleida.part_name);
                        Leer = EBRleida.part_next;
                        tt++;
                    }

                  ///  printf("Se modifica el siguiente de %s\n",EBRleida.part_name);
                    EBRleida.part_next = SiguienteAhora;
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);


                }

            }


        }



        if(lectura.mbr_partition_3.particion_status != '0')
        {

            if(!strcmp(lectura.mbr_partition_3.part_name,nombre))
            {

              ///  printf("La 3 es la que quiero eliminar\n");
              ///  printf("Nombre:      %s\n",lectura.mbr_partition_3.part_name);
                lectura.mbr_partition_3.particion_status = '0';

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                ///printf("Eliminada la particion de Forma Fast\n");
                return;
            }
            else if(lectura.mbr_partition_3.part_type == 'e')   ///si es una extendida
            {


                int Leer = lectura.mbr_partition_3.part_start;
                int logicleidas=0;
                int SiguienteAhora = 0;
                int TamanioLogica =0;
                int InicioLogica = 0;
                int halle = 0;

                while(Leer != -1)
                {

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    logicleidas++;
                    TamanioLogica = EBRleida.part_size;
                    InicioLogica = EBRleida.part_start;
                    SiguienteAhora = EBRleida.part_next;

                    if(!strcmp(EBRleida.part_name,nombre))
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion Logica %s de Forma Fast\n",nombre);
                        halle = 1;
                        break;
                    }


                    if(EBRleida.part_next == -1 && !strcmp(EBRleida.part_name,nombre) )
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion logica %s de Forma Fast\n",nombre);
                        halle = 1;
                        break;

                    }

                    Leer = EBRleida.part_next;

                }

                // printf("Parte logica 3 \n");
                //printf("Tamanio Logica %d\n",TamanioLogica);
                //printf("Inicio Logica  %d\n",InicioLogica);
                //printf("Siguiente ahora %d\n",SiguienteAhora);
                //printf("Leer %d\n",Leer);
                //printf("logicleidas %d\n",logicleidas);


                if(logicleidas > 1 && halle == 1)
                {
                   /// printf("Entre a mayor a 1 \n");

                    // fseek(arch,Leer,SEEK_SET);
                    //fread(&EBRleida,sizeof(EBR),1,arch);
                    //fwrite(&EBRleida,sizeof(EBR),1,arch);
                    int tt = 0;
                    Leer = lectura.mbr_partition_3.part_start;

                    while(tt != logicleidas-1)
                    {
                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                        ///printf("El nombre de esta es %s\n",EBRleida.part_name);
                        Leer = EBRleida.part_next;
                        tt++;
                    }

                  ///  printf("Se modifica el siguiente de %s\n",EBRleida.part_name);
                    EBRleida.part_next = SiguienteAhora;
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);


                }

            }


        }



        if(lectura.mbr_partition_4.particion_status != '0')
        {

            if(!strcmp(lectura.mbr_partition_4.part_name,nombre))
            {

              ///  printf("La 4 es la que quiero eliminar\n");
               /// printf("Nombre:      %s\n",lectura.mbr_partition_4.part_name);
                lectura.mbr_partition_4.particion_status = '0';

                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Fast\n");
                return;
            }
            else if(lectura.mbr_partition_4.part_type == 'e')  ///si es una extendida
            {


                int Leer = lectura.mbr_partition_4.part_start;
                int logicleidas=0;
                int SiguienteAhora = 0;
                int TamanioLogica =0;
                int InicioLogica = 0;
                int halle = 0;

                while(Leer != -1)
                {

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);
                    logicleidas++;
                    TamanioLogica = EBRleida.part_size;
                    InicioLogica = EBRleida.part_start;
                    SiguienteAhora = EBRleida.part_next;

                    if(!strcmp(EBRleida.part_name,nombre))
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion Logica %s de Forma Fast\n",nombre);
                        halle = 1;
                        break;
                    }


                    if(EBRleida.part_next == -1 && !strcmp(EBRleida.part_name,nombre) )
                    {

                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        printf("Eliminada la particion logica %s de Forma Fast\n",nombre);
                        halle = 1;
                        break;

                    }

                    Leer = EBRleida.part_next;

                }

                //  printf("Parte logica 4 \n");
                // printf("Tamanio Logica %d\n",TamanioLogica);
                // printf("Inicio Logica  %d\n",InicioLogica);
                // printf("Siguiente ahora %d\n",SiguienteAhora);
                // printf("Leer %d\n",Leer);
                // printf("logicleidas %d\n",logicleidas);


                if(logicleidas > 1 && halle == 1)
                {
                   /// printf("Entre a mayor a 1 \n");

                    // fseek(arch,Leer,SEEK_SET);
                    //fread(&EBRleida,sizeof(EBR),1,arch);
                    //fwrite(&EBRleida,sizeof(EBR),1,arch);
                    int tt = 0;
                    Leer = lectura.mbr_partition_4.part_start;

                    while(tt != logicleidas-1)
                    {
                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                   ///     printf("El nombre de esta es %s\n",EBRleida.part_name);
                        Leer = EBRleida.part_next;
                        tt++;
                    }

                  ///  printf("Se modifica el siguiente de %s\n",EBRleida.part_name);
                    EBRleida.part_next = SiguienteAhora;
                    fseek(arch,EBRleida.part_start,SEEK_SET);
                    fwrite(&EBRleida,sizeof(EBR),1,arch);


                }

            }


        }


    }
    else
    {
        printf("Error en Lectura del MBR  ");
        return;
    }
    fclose(arch);



}



void EliminarParticionFull(char *nombre, char *ruta)
{
    FILE *arch = fopen(ruta,"rb+");


    if (arch!=NULL)
    {


        MBRdisco lectura;
        EBR EBRleida;
        int byteInicio = 0;

        fseek(arch,0,SEEK_SET);
        fread(&lectura,sizeof(MBRdisco),1,arch);


        if(lectura.mbr_partition_1.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(lectura.mbr_partition_1.part_name,nombre))
            {

              ///  printf("La primera es la que quiero eliminar\n");
              ///  printf("nombre: %s\n",lectura.mbr_partition_1.part_name);
                fseek(arch,lectura.mbr_partition_1.part_start,SEEK_SET);
                char cero = '\0';
                fwrite(&cero,sizeof(char),lectura.mbr_partition_1.part_size,arch);
                lectura.mbr_partition_1.particion_status = '0';
                lectura.mbr_partition_1.part_fit = ' ';
                strcpy(lectura.mbr_partition_1.part_name,"");
                lectura.mbr_partition_1.part_size = -1;
                lectura.mbr_partition_1.part_start = -1;
                lectura.mbr_partition_1.part_type =' ';
                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;
            }
            else if(lectura.mbr_partition_1.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_1.part_start;
                int logicleidas=0;
                int SiguienteDeBorrada =0;
                int InicioAnterior = 0;

                while(Leer != -1)
                {

                    logicleidas++;

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);


                    SiguienteDeBorrada = EBRleida.part_next;



                    if(!strcmp(EBRleida.part_name,nombre) && logicleidas == 1)
                    {
                  ///      printf("Hallada la logica a eliminar\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        InicioAnterior = EBRleida.part_start;
                    ///    printf("Se llama %s, y ahora su status es %c, y empieza info en %d, LEER va %d\n",EBRleida.part_name,EBRleida.part_status,EBRleida.part_start,Leer);
                        fseek(arch,Leer,SEEK_SET);
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,InicioAnterior+sizeof(EBR),SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }


                    if(!strcmp(EBRleida.part_name,nombre)  && logicleidas != 1)
                    {
                      ///  printf("hallada la logica a eliminar y no es la priemra\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,EBRleida.part_start,SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }

                    Leer = EBRleida.part_next;
                  ///  printf("EBR leida %d\n",EBRleida.part_next);


                }

                if(logicleidas >1)
                {
                    int xu=0;
                    Leer = lectura.mbr_partition_1.part_start;
                    int xtam = 0;
                    while(xu < logicleidas-1)
                    {

                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                        Leer = EBRleida.part_next;
                        xtam = EBRleida.part_size;
                        xu++;
                    }

               ///     printf("Ahora vamos a poner este next %d a la particion llamda %s , que empieza en %d\n",SiguienteDeBorrada,EBRleida.part_name,Leer-xtam);

                    fseek(arch,Leer-xtam,SEEK_SET);
                    EBRleida.part_next = SiguienteDeBorrada;
                    fwrite(&EBRleida,sizeof(EBR),1,arch);

                }

                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;



            }




        }

        if(lectura.mbr_partition_2.part_start != -1 && lectura.mbr_partition_2.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {


            if(!strcmp(lectura.mbr_partition_2.part_name,nombre))
            {

               /// printf("La 2 es la que quiero eliminar\n");
                fseek(arch,lectura.mbr_partition_2.part_start,SEEK_SET);
                char cero = '\0';
                fwrite(&cero,sizeof(char),lectura.mbr_partition_2.part_size,arch);
                lectura.mbr_partition_2.particion_status = '0';
                lectura.mbr_partition_2.part_fit = ' ';
                strcpy(lectura.mbr_partition_2.part_name,"");
                lectura.mbr_partition_2.part_size = -1;
                lectura.mbr_partition_2.part_start = -1;
                lectura.mbr_partition_2.part_type =' ';
                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;
            }
            else if(lectura.mbr_partition_2.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_2.part_start;
                int logicleidas=0;
                int SiguienteDeBorrada =0;
                int InicioAnterior = 0;

                while(Leer != -1)
                {

                    logicleidas++;

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);


                    SiguienteDeBorrada = EBRleida.part_next;



                    if(!strcmp(EBRleida.part_name,nombre) && logicleidas == 1)
                    {
                    ///    printf("Hallada la logica a eliminar\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        InicioAnterior = EBRleida.part_start;
                     ///   printf("Se llama %s, y ahora su status es %c, y empieza info en %d, LEER va %d\n",EBRleida.part_name,EBRleida.part_status,EBRleida.part_start,Leer);
                        fseek(arch,Leer,SEEK_SET);
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,InicioAnterior+sizeof(EBR),SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }


                    if(!strcmp(EBRleida.part_name,nombre)  && logicleidas != 1)
                    {
                       /// printf("hallada la logica a eliminar y no es la priemra\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,EBRleida.part_start,SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }

                    Leer = EBRleida.part_next;
                    printf("EBR leida %d\n",EBRleida.part_next);


                }

                if(logicleidas >1)
                {
                    int xu=0;
                    Leer = lectura.mbr_partition_2.part_start;
                    int xtam = 0;
                    while(xu < logicleidas-1)
                    {

                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                        Leer = EBRleida.part_next;
                        xtam = EBRleida.part_size;
                        xu++;
                    }

                   /// printf("Ahora vamos a poner este next %d a la particion llamda %s , que empieza en %d\n",SiguienteDeBorrada,EBRleida.part_name,Leer-xtam);

                    fseek(arch,Leer-xtam,SEEK_SET);
                    EBRleida.part_next = SiguienteDeBorrada;
                    fwrite(&EBRleida,sizeof(EBR),1,arch);

                }

                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;



            }






        }

        if(lectura.mbr_partition_3.part_start != -1 && lectura.mbr_partition_3.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {


            if(!strcmp(lectura.mbr_partition_3.part_name,nombre))
            {

               /// printf("La 3 es la que quiero eliminar\n");
                fseek(arch,lectura.mbr_partition_3.part_start,SEEK_SET);
                char cero = '\0';
                fwrite(&cero,sizeof(char),lectura.mbr_partition_3.part_size,arch);
                lectura.mbr_partition_3.particion_status = '0';
                lectura.mbr_partition_3.part_fit = ' ';
                strcpy(lectura.mbr_partition_3.part_name,"");
                lectura.mbr_partition_3.part_size = -1;
                lectura.mbr_partition_3.part_start = -1;
                lectura.mbr_partition_3.part_type =' ';
                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;
            }
            else if(lectura.mbr_partition_3.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_3.part_start;
                int logicleidas=0;
                int SiguienteDeBorrada =0;
                int InicioAnterior = 0;

                while(Leer != -1)
                {

                    logicleidas++;

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);


                    SiguienteDeBorrada = EBRleida.part_next;



                    if(!strcmp(EBRleida.part_name,nombre) && logicleidas == 1)
                    {
                      ///  printf("Hallada la logica a eliminar\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        InicioAnterior = EBRleida.part_start;
                        // printf("Se llama %s, y ahora su status es %c, y empieza info en %d, LEER va %d\n",EBRleida.part_name,EBRleida.part_status,EBRleida.part_start,Leer);
                        fseek(arch,Leer,SEEK_SET);
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,InicioAnterior+sizeof(EBR),SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }


                    if(!strcmp(EBRleida.part_name,nombre)  && logicleidas != 1)
                    {
                     ///   printf("hallada la logica a eliminar y no es la priemra\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,EBRleida.part_start,SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }

                    Leer = EBRleida.part_next;
                 ///   printf("EBR leida %d\n",EBRleida.part_next);


                }

                if(logicleidas >1)
                {
                    int xu=0;
                    Leer = lectura.mbr_partition_3.part_start;
                    int xtam = 0;
                    while(xu < logicleidas-1)
                    {

                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                        Leer = EBRleida.part_next;
                        xtam = EBRleida.part_size;
                        xu++;
                    }

                  ///  printf("Ahora vamos a poner este next %d a la particion llamda %s , que empieza en %d\n",SiguienteDeBorrada,EBRleida.part_name,Leer-xtam);

                    fseek(arch,Leer-xtam,SEEK_SET);
                    EBRleida.part_next = SiguienteDeBorrada;
                    fwrite(&EBRleida,sizeof(EBR),1,arch);

                }

                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;



            }



        }

        if(lectura.mbr_partition_4.part_start != -1 && lectura.mbr_partition_4.particion_status != '0')         ///si la particion uno esta activa imprimirmos sus informaciones
        {

            if(!strcmp(lectura.mbr_partition_4.part_name,nombre))
            {

            ///    printf("La 4 es la que quiero eliminar\n");
                fseek(arch,lectura.mbr_partition_4.part_start,SEEK_SET);
                char cero = '\0';
                fwrite(&cero,sizeof(char),lectura.mbr_partition_4.part_size,arch);
                lectura.mbr_partition_4.particion_status = '0';
                lectura.mbr_partition_4.part_fit = ' ';
                strcpy(lectura.mbr_partition_4.part_name,"");
                lectura.mbr_partition_4.part_size = -1;
                lectura.mbr_partition_4.part_start = -1;
                lectura.mbr_partition_4.part_type =' ';
                fseek(arch,0,SEEK_SET);
                fwrite(&lectura,sizeof(MBRdisco),1,arch);
                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;
            }
            else if(lectura.mbr_partition_4.part_type == 'e')
            {

                int Leer = lectura.mbr_partition_4.part_start;
                int logicleidas=0;
                int SiguienteDeBorrada =0;
                int InicioAnterior = 0;

                while(Leer != -1)
                {

                    logicleidas++;

                    fseek(arch,Leer,SEEK_SET);
                    fread(&EBRleida,sizeof(EBR),1,arch);


                    SiguienteDeBorrada = EBRleida.part_next;



                    if(!strcmp(EBRleida.part_name,nombre) && logicleidas == 1)
                    {
                     ///   printf("Hallada la logica a eliminar\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        EBRleida.part_size = 0;
                        InicioAnterior = EBRleida.part_start;
                    ///    printf("Se llama %s, y ahora su status es %c, y empieza info en %d, LEER va %d\n",EBRleida.part_name,EBRleida.part_status,EBRleida.part_start,Leer);
                        fseek(arch,Leer,SEEK_SET);
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,InicioAnterior+sizeof(EBR),SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }


                    if(!strcmp(EBRleida.part_name,nombre)  && logicleidas != 1)
                    {
                    ///    printf("hallada la logica a eliminar y no es la priemra\n");
                        fseek(arch,Leer,SEEK_SET);
                        EBRleida.part_status = '0';
                        fwrite(&EBRleida,sizeof(EBR),1,arch);
                        char cero = '\0';
                        fseek(arch,EBRleida.part_start,SEEK_SET);
                        fwrite(&cero,sizeof(char),EBRleida.part_size,arch);
                        break;

                    }

                    Leer = EBRleida.part_next;
                  ///  printf("EBR leida %d\n",EBRleida.part_next);


                }

                if(logicleidas >1)
                {
                    int xu=0;
                    Leer = lectura.mbr_partition_4.part_start;
                    int xtam = 0;
                    while(xu < logicleidas-1)
                    {

                        fseek(arch,Leer,SEEK_SET);
                        fread(&EBRleida,sizeof(EBR),1,arch);
                        Leer = EBRleida.part_next;
                        xtam = EBRleida.part_size;
                        xu++;
                    }

                ///    printf("Ahora vamos a poner este next %d a la particion llamda %s , que empieza en %d\n",SiguienteDeBorrada,EBRleida.part_name,Leer-xtam);

                    fseek(arch,Leer-xtam,SEEK_SET);
                    EBRleida.part_next = SiguienteDeBorrada;
                    fwrite(&EBRleida,sizeof(EBR),1,arch);

                }

                fclose(arch);
                printf("Eliminada la particion de Forma Full\n");
                return;



            }




        }

    }
    else
    {
        printf("Error en Lectura del MBR  ");
        return;
    }
    fclose(arch);
}



particionMontada buscarParticion(char* id)
{

    int zz;
    particionMontada af ;
    af.byteInicio = -1000;

    for(zz; zz < cantidadParticionesMontadas; zz++)
    {

        if(!strcmp(ParticionesMontadas[zz].id,id))
        {

            return ParticionesMontadas[zz];

        }


    }

    return af;


}

#endif // DISCOS_H_INCLUDED
